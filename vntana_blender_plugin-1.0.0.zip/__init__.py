# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin
#
# A Blender addon for exporting assets to and importing from VNTANA platform.

class IconStore:
    def __init__(self):
        self.preview_collections = None
        self.thumbnail_state = {}


icons = IconStore()


def get_icons():
    global icons
    return icons


def register():
    from . import core
    core.initialize(__package__)

    """Register the addon."""
    import bpy.utils.previews
    from . import properties
    from . import operators
    from . import panels

    # Initialize logging
    log = core.logger.setup_logging()
    log.info(
        f"Registering VNTANA plugin.")

    global icons
    # Create preview collection for thumbnails
    icons.preview_collections = bpy.utils.previews.new()

    # Register in order: properties -> operators -> panels
    properties.register()
    operators.register()
    panels.register()

    from .api import init_api
    from .core import get_preferences
    import bpy
    system = bpy.context.preferences.system
    init_api(
        get_preferences().preferences.base_url,
        timeout=getattr(system, 'network_timeout', 0),
        connection_limit=getattr(system, 'network_connection_limit', 0),
    )

    # Try to load PAT from Windows Credential Manager
    try:
        from .core.credentials import cred_read
        pat = cred_read("vnt-plugin")
        if pat:
            get_preferences().preferences.ui.login_pat = pat
    except Exception as e:
        log.warning(f"Failed to read PAT from credential manager: {e}")

    bpy.app.handlers.load_post.append(_auto_login)

    log.info("VNTANA plugin registered successfully")


def unregister():
    """Unregister the addon."""
    import bpy.utils.previews
    from . import panels
    from . import operators
    from . import properties
    from .core import logger, get_loop, shutdown
    from .api import vnt_api_async

    log = logger.get_logger()
    log.info("Unregistering VNTANA plugin")

    # Unregister in reverse order: panels -> operators -> properties
    panels.unregister()
    operators.unregister()
    properties.unregister()

    # Clean up preview collections
    global icons
    bpy.utils.previews.remove(icons.preview_collections)
    icons = IconStore()

    # Reset API state
    core.get_loop().run_until_complete(vnt_api_async.reset_async_api())
    core.shutdown()

    log.info("VNTANA plugin unregistered")


def _auto_login(scene):
    """Schedule auto-login after Blender is fully loaded, if user has enabled it."""
    import bpy

    """Timer function that runs auto-login if enabled in preferences."""
    # Check if auto-login is enabled in preferences
    if bpy.context.window:
        from .core import get_preferences
        addon_prefs = get_preferences()
        if addon_prefs and addon_prefs.preferences and addon_prefs.preferences.enable_auto_login and bpy.ops.vntana.login.poll():
            bpy.ops.vntana.login(
                'INVOKE_DEFAULT', pat=addon_prefs.preferences.ui.login_pat)


# Allow running as script for development
if __name__ == "__main__":
    register()
