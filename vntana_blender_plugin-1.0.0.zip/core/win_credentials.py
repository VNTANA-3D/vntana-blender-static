from ctypes import *
from ctypes.wintypes import DWORD, BOOL, LPWSTR, FILETIME, LPBYTE

CRED_TYPE_GENERIC = 1

_advapi32 = windll.advapi32


class CREDENTIAL(Structure):
    _fields_ = [
        ("Flags", DWORD),
        ("Type", DWORD),
        ("TargetName", LPWSTR),
        ("Comment", LPWSTR),
        ("LastWritten", FILETIME),
        ("CredentialBlobSize", DWORD),
        ("CredentialBlob", LPBYTE),
        ("Persist", DWORD),
        ("AttributeCount", DWORD),
        ("Attributes", c_void_p),
        ("TargetAlias", LPWSTR),
        ("UserName", LPWSTR),
    ]


PCREDENTIAL = POINTER(CREDENTIAL)

_CredReadW = _advapi32.CredReadW
_CredReadW.argtypes = [LPWSTR, DWORD, DWORD, POINTER(PCREDENTIAL)]
_CredReadW.restype = BOOL

_CredWriteW = _advapi32.CredWriteW
_CredWriteW.argtypes = [POINTER(CREDENTIAL), DWORD]
_CredWriteW.restype = BOOL

_CredFree = _advapi32.CredFree
_CredFree.argtypes = [c_void_p]
_CredFree.restype = None

CRED_PERSIST_LOCAL_MACHINE = 2


def cred_read(target_name: str) -> str | None:
    """Read a generic credential from Windows Credential Manager and return the password."""
    cred_ptr = PCREDENTIAL()
    if not _CredReadW(target_name, CRED_TYPE_GENERIC, 0, byref(cred_ptr)):
        return None
    try:
        cred = cred_ptr.contents
        if cred.CredentialBlob and cred.CredentialBlobSize:
            blob = string_at(cred.CredentialBlob, cred.CredentialBlobSize)
            return blob.decode("utf-16-le")
        return None
    finally:
        _CredFree(cred_ptr)


def cred_write(target_name: str, password: str, username: str = "") -> bool:
    """Write a generic credential to Windows Credential Manager. Returns True on success."""
    blob = password.encode("utf-16-le")
    cred = CREDENTIAL()
    cred.Type = CRED_TYPE_GENERIC
    cred.TargetName = target_name
    cred.CredentialBlobSize = len(blob)
    cred.CredentialBlob = cast(c_char_p(blob), LPBYTE)
    cred.Persist = CRED_PERSIST_LOCAL_MACHINE
    cred.UserName = username or None
    return bool(_CredWriteW(byref(cred), 0))
