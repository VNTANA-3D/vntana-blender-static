import asyncio
import bpy
from pathlib import Path
from .thumbnail_cache import get_thumbnail_cache_directory, clear_thumbnail_cache

_ADDON_ID = ""
_loop: asyncio.AbstractEventLoop | None = None


def initialize(addon_id):
    global _ADDON_ID
    global _loop

    _ADDON_ID = addon_id
    _loop = asyncio.new_event_loop()

    thumbnail_cache_dir = get_thumbnail_cache_directory()
    thumbnail_cache_dir.mkdir(parents=True, exist_ok=True)


def shutdown():
    global _loop
    _loop.close()
    _loop = None
    # TODO(ivan): use OS's temporary dir and let it clean up?
    clear_thumbnail_cache()


def create_task(task):
    global _loop
    if not bpy.app.timers.is_registered(tick):
        bpy.app.timers.register(tick, first_interval=0.05, persistent=True)

    return _loop.create_task(task)


def is_empty():
    global _loop
    return len(asyncio.all_tasks(_loop)) == 0


def tick():
    global _loop
    if is_empty():
        return None

    try:
        _loop.stop()
        _loop.run_forever()
    except Exception:
        import traceback
        traceback.print_exc()
        return None

    return 0.05


def get_loop():
    global _loop
    return _loop


def tag_redraw(context):
    # TODO(ivan): redraw only parts of UI we care about
    for area in context.screen.areas:
        area.tag_redraw()


def get_addon_id():
    global _ADDON_ID
    return _ADDON_ID


def get_preferences():
    addon_id = get_addon_id()
    return bpy.context.preferences.addons.get(addon_id)
