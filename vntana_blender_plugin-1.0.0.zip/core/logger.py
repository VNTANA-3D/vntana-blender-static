# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Logging Utilities

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path

_logger = None
_log_path = None


def get_log_directory() -> Path:
    """Get platform-appropriate log directory."""
    import sys

    if sys.platform == 'darwin':
        base = Path.home() / 'Library' / 'Application Support' / \
            'VNTANA' / 'vntana-blender-plugin'
    elif sys.platform == 'win32':
        base = Path(os.environ.get('APPDATA', Path.home())) / \
            'VNTANA' / 'vntana-blender-plugin'
    else:
        base = Path.home() / '.vntana' / 'vntana-blender-plugin'

    base.mkdir(parents=True, exist_ok=True)
    return base


def setup_logging(name: str = 'vntana', level: int = None) -> logging.Logger:
    """
    Set up logging with rotating file handler.

    Args:
        name: Logger name
        level: Logging level

    Returns:
        Configured logger instance
    """
    global _logger, _log_path

    if _logger is not None:
        return _logger

    if level is None:
        level = logging.INFO
        try:
            from .core import get_preferences
            addon = get_preferences()
            if addon and addon.preferences and addon.preferences.enable_debug_logging:
                level = logging.DEBUG
        except Exception:
            pass

    _logger = logging.getLogger(name)
    _logger.setLevel(level)

    # Prevent duplicate handlers
    if _logger.handlers:
        return _logger

    # Create log directory
    log_dir = get_log_directory()
    _log_path = log_dir / 'vntana-blender.log'

    # Rotating file handler (100KB max, 1 backup)
    file_handler = RotatingFileHandler(
        _log_path,
        maxBytes=100 * 1024,
        backupCount=1,
        encoding='utf-8'
    )
    file_handler.setLevel(level)

    # Set restrictive permissions on log file (owner read/write only)
    try:
        os.chmod(_log_path, 0o600)
    except OSError:
        pass  # chmod may have limited effect on Windows

    # Console handler for Blender's console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(name)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    _logger.addHandler(file_handler)
    _logger.addHandler(console_handler)

    # Suppress noisy libraries
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)

    _logger.info(f"VNTANA logging initialized. Log file: {_log_path}")

    return _logger


def get_logger() -> logging.Logger:
    """Get or create the VNTANA logger."""
    global _logger
    if _logger is None:
        _logger = setup_logging()
    return _logger


def get_log_path() -> Path:
    """Get the path to the current log file."""
    global _log_path
    if _log_path is None:
        setup_logging()
    return _log_path


def set_debug_logging(enabled: bool) -> None:
    """
    Enable or disable debug logging at runtime.

    Adjusts logger and file handler levels without requiring a restart.
    """
    global _logger
    level = logging.DEBUG if enabled else logging.INFO

    if _logger is None:
        setup_logging(level=level)
        return

    _logger.setLevel(level)

    # Keep console at INFO; file handler follows logger level
    for handler in _logger.handlers:
        if isinstance(handler, RotatingFileHandler):
            handler.setLevel(level)
