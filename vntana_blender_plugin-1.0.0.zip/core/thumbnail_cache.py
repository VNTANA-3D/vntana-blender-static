# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Thumbnail Cache

import os
from pathlib import Path


def get_thumbnail_cache_directory() -> Path:
    """Get platform-appropriate directory for thumbnail cache."""
    import sys

    if sys.platform == 'darwin':
        base = Path.home() / 'Library' / 'Application Support' / \
            'VNTANA' / 'vntana-blender-plugin' / 'thumbnails'
    elif sys.platform == 'win32':
        base = Path(os.environ.get('APPDATA', Path.home())) / \
            'VNTANA' / 'vntana-blender-plugin' / 'thumbnails'
    else:
        base = Path.home() / '.vntana' / 'vntana-blender-plugin' / 'thumbnails'

    return base


def clear_thumbnail_cache() -> bool:
    try:
        dir = get_thumbnail_cache_directory()
        for file in dir.iterdir():
            if file.is_file() and file.suffix == '.png':
                file.unlink()
    except Exception:
        pass
