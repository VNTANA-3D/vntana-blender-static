from ctypes import (
    CDLL,
    POINTER,
    byref,
    c_char_p,
    c_int32,
    c_uint32,
    c_void_p,
    string_at,
)
from ctypes.util import find_library

_security = CDLL(find_library("Security"))
_cf = CDLL(find_library("CoreFoundation"))

OSStatus = c_int32
UInt32 = c_uint32

errSecSuccess = 0

_SecKeychainFindGenericPassword = _security.SecKeychainFindGenericPassword
_SecKeychainFindGenericPassword.argtypes = [
    c_void_p, UInt32, c_char_p, UInt32, c_char_p,
    POINTER(UInt32), POINTER(c_void_p), POINTER(c_void_p),
]
_SecKeychainFindGenericPassword.restype = OSStatus

_SecKeychainAddGenericPassword = _security.SecKeychainAddGenericPassword
_SecKeychainAddGenericPassword.argtypes = [
    c_void_p, UInt32, c_char_p, UInt32, c_char_p,
    UInt32, c_char_p, POINTER(c_void_p),
]
_SecKeychainAddGenericPassword.restype = OSStatus

_SecKeychainItemModifyAttributesAndData = _security.SecKeychainItemModifyAttributesAndData
_SecKeychainItemModifyAttributesAndData.argtypes = [
    c_void_p, c_void_p, UInt32, c_char_p,
]
_SecKeychainItemModifyAttributesAndData.restype = OSStatus

_SecKeychainItemFreeContent = _security.SecKeychainItemFreeContent
_SecKeychainItemFreeContent.argtypes = [c_void_p, c_void_p]
_SecKeychainItemFreeContent.restype = OSStatus

_CFRelease = _cf.CFRelease
_CFRelease.argtypes = [c_void_p]
_CFRelease.restype = None


def cred_read(target_name: str) -> str | None:
    """Read a generic credential from macOS Keychain and return the password."""
    service_bytes = target_name.encode("utf-8")
    password_length = UInt32(0)
    password_data = c_void_p()
    item_ref = c_void_p()

    status = _SecKeychainFindGenericPassword(
        None,
        len(service_bytes), service_bytes,
        0, None,
        byref(password_length), byref(password_data), byref(item_ref),
    )
    if status != errSecSuccess or not password_data:
        return None

    try:
        blob = string_at(password_data, password_length.value)
        return blob.decode("utf-8")
    finally:
        _SecKeychainItemFreeContent(None, password_data)
        if item_ref:
            _CFRelease(item_ref)


def cred_write(target_name: str, password: str, username: str = "") -> bool:
    """Write a generic credential to macOS Keychain. Returns True on success."""
    service_bytes = target_name.encode("utf-8")
    account_bytes = username.encode("utf-8")
    password_bytes = password.encode("utf-8")

    account_arg = account_bytes if account_bytes else None

    existing_item = c_void_p()
    status = _SecKeychainFindGenericPassword(
        None,
        len(service_bytes), service_bytes,
        len(account_bytes), account_arg,
        None, None, byref(existing_item),
    )
    if status == errSecSuccess and existing_item:
        try:
            status = _SecKeychainItemModifyAttributesAndData(
                existing_item, None, len(password_bytes), password_bytes,
            )
        finally:
            _CFRelease(existing_item)
        return status == errSecSuccess

    status = _SecKeychainAddGenericPassword(
        None,
        len(service_bytes), service_bytes,
        len(account_bytes), account_arg,
        len(password_bytes), password_bytes,
        None,
    )
    return status == errSecSuccess
