import os

if os.name == 'nt':
    from .win_credentials import cred_read, cred_write
else:
    from .mac_credentials import cred_read, cred_write
