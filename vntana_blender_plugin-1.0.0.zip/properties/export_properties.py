# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Export Properties

import re
import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    IntProperty,
    EnumProperty,
    StringProperty,
    FloatProperty,
)
from bpy.types import PropertyGroup
from ..api import get_async_api

# Input validation constants
MAX_ASSET_NAME_LENGTH = 255
MAX_TAG_LENGTH = 64
MAX_DESCRIPTION_LENGTH = 2000
# Pattern for valid asset names: alphanumeric, spaces, hyphens, underscores, periods
VALID_ASSET_NAME_PATTERN = re.compile(r'^[a-zA-Z0-9\s\-_.]*$')
# Pattern for valid tags: alphanumeric, hyphens, underscores (no spaces)
VALID_TAG_PATTERN = re.compile(r'^[a-zA-Z0-9\-_]*$')


def sanitize_asset_name(value: str) -> str:
    """Sanitize asset name by removing invalid characters."""
    # Remove characters that don't match the allowed pattern
    sanitized = ''.join(c for c in value if VALID_ASSET_NAME_PATTERN.match(c))
    # Truncate to max length
    return sanitized[:MAX_ASSET_NAME_LENGTH]


def update_asset_name(self, context):
    """Update callback to sanitize asset name."""
    sanitized = sanitize_asset_name(self.asset_name)
    if sanitized != self.asset_name:
        self.asset_name = sanitized


def update_file_size_limit(self, context):
    if self.file_size_limit:
        self.texture_optimization = True


def update_texture_optimization(self, context):
    if not self.texture_optimization:
        self.file_size_limit = False


def clamp(value, min_val, max_val):
    """Clamp a value to a range, ensuring hard constraints are enforced."""
    return max(min_val, min(max_val, value))


# Hard constraints for API values (enforced at API submission time)
POLYGON_LIMIT_MIN = 1000
POLYGON_LIMIT_MAX = 1000000
AO_STRENGTH_MIN = 1
AO_STRENGTH_MAX = 10
AO_RADIUS_MIN = 1
AO_RADIUS_MAX = 20
TEXTURE_COMPRESSION_MIN = 1
TEXTURE_COMPRESSION_MAX = 5
VALID_TEXTURE_DIMENSIONS = {'512', '1024', '2048', '4096', '8192'}
VALID_AO_RESOLUTIONS = {'512', '1024', '2048', '4096'}
VALID_PIVOT_POINTS = {'center', 'bottom', 'origin'}


def tag_search(self, context, edit_text):
    api = get_async_api()
    return [tag.get('name', '') for tag in api.tags]


class VNTANATag(PropertyGroup):
    name: StringProperty(name="Name", default="", search=tag_search)


class VNTANAAttribute(PropertyGroup):
    name: StringProperty(name="Name", default="")
    value: StringProperty(name="Value", default="")


class VNTANAExportSettings(PropertyGroup):
    """Export settings PropertyGroup."""

    # =========================================================================
    # Basic Export Options
    # =========================================================================

    file_size_limit: BoolProperty(
        name="File Size Limit",
        description="The maximum file size limit for the optimized GLB file.",
        default=False,
        update=update_file_size_limit
    )
    file_size_limit_in_mb: FloatProperty(
        name="File Size in MB",
        default=5
    )
    force_file_size_limit: BoolProperty(
        name="Force File Size Limit",
        default=False
    )

    # =========================================================================
    # Geometry Optimization
    # =========================================================================

    geometry_optimization: BoolProperty(
        name="Geometry Optimization",
        description="Enable Geometry Optimizations.",
        default=True
    )

    remove_obstructed_geometry: BoolProperty(
        name="Remove Obstructed Geometry",
        description="Remove geometry that cannot be seen from outside the model",
        default=True
    )

    polygon_limit: IntProperty(
        name="Polygon Limit",
        description="Target polygon count after optimization.",
        default=75000,
        min=2,
        max=1000000,
        soft_min=1000,
        soft_max=100000
    )
    force_polygon_count: BoolProperty(
        name="Force Polygon Count",
        description="Force the exact polygon count (may affect quality)",
        default=False
    )

    small_feature_baking: BoolProperty(
        name="Small Feature Baking",
        description="Bake small features (such as stitches) into alpha masked quads."
    )

    freeze_transforms: BoolProperty(
        name="Freeze Transform",
        description="Force the exact polygon count (may affect quality)",
        default=False
    )

    draco_compression: BoolProperty(
        name="Draco Compression",
        description="Apply Draco Compression to GLB output",
        default=True
    )

    # =========================================================================
    # Texture Optimization
    # =========================================================================

    texture_optimization: BoolProperty(
        name="Enable Texture Optimization",
        description="Apply compression, resize and adjust texture maps based on given settings.",
        default=True,
        update=update_texture_optimization
    )

    texture_compression: EnumProperty(
        name="Compression Level",
        description="Texture compression level (1=lowest, 5=highest)",
        items=[
            ('0', '0', 'Lossless texture compression'),
            ('1', '1', 'Minimal compression, highest quality'),
            ('2', '2', 'Low compression'),
            ('3', '3', 'Balanced compression and quality'),
            ('4', '4', 'High compression'),
            ('5', '5', 'Maximum compression, lowest quality'),
        ],
        default='2'
    )

    max_texture_dimension: EnumProperty(
        name="Max Dimension",
        description="Maximum texture dimension",
        items=[
            ('512', '512', '512x512 pixels'),
            ('1024', '1024', '1024x1024 pixels'),
            ('2048', '2048', '2048x2048 pixels'),
            ('4096', '4096', '4096x4096 pixels'),
            ('8192', '8192', '8192x8192 pixels'),
        ],
        default='4096'
    )

    use_ktx: BoolProperty(
        name="Use KTX Format",
        description="Use KTX texture format for better compression",
        default=False
    )

    # =========================================================================
    # Ambient Occlusion
    # =========================================================================
    bake_ambient_occlusion: BoolProperty(
        name="Bake Ambient Occlusion",
        description="Bake ambient occlusion into the model",
        default=True
    )

    ao_strength: IntProperty(
        name="AO Strength",
        description="Ambient occlusion strength (1-10)",
        default=1,
        min=1,
        max=10
    )

    ao_radius: IntProperty(
        name="AO Radius",
        description="Ambient occlusion radius",
        default=5,
        min=1,
        max=20
    )

    ao_resolution: EnumProperty(
        name="AO Resolution",
        description="Ambient occlusion bake resolution",
        items=[
            ('512', '512', '512x512 pixels'),
            ('1024', '1K', '1024x1024 pixels'),
            ('2048', '2K', '2048x2048 pixels'),
        ],
        default='1024'
    )

    fbx_pbr_textures: BoolProperty(
        name="FBX PBR Textures",
        description="Output PBR materials instead of Phong material",
        default=False
    )

    model_scaling: BoolProperty(
        name="3D Model Scaling",
        description="Change the size of the 3D model",
        default=False
    )

    axis_to_scale_on: EnumProperty(
        name="Axis to Scale on",
        items=[('X', 'X', ''), ('Y', 'Y', ''), ('Z', 'Z', '')],
        default='Y'
    )

    size: FloatProperty(
        name="Size",
        default=1.0
    )

    unit: EnumProperty(
        name="Unit",
        items=[('cm', 'cm', ''), ('m', 'm', ''), ('in', 'in', '')],
        default='m'
    )
    # =========================================================================
    # Pivot Point
    # =========================================================================
    pivot_point: EnumProperty(
        name="Pivot Point",
        description="Pivot point alignment",
        items=[
            ('center', 'Center', ''),
            ('bottom-center', 'Bottom Center', ''),
            ('none', 'None', 'Keep original origin'),
            ('back-bottom-center', 'Back Bottom Center', ''),
            ('back-center', 'Bottom Center', ''),
            ('front-center', 'Bottom Center', ''),
            ('top-center', 'Top Center', ''),
        ],
        default='center'
    )

    publish_to_status: EnumProperty(
        name="Publish Status",
        items=[
            ('DRAFT', "Draft", ""),
            ('LIVE_INTERNAL', "Live Internal", ""),
            ('LIVE_PUBLIC', "Live Public", ""),
        ],
    )

    def get_model_ops_parameters(self) -> dict:
        params = {
            'PIVOT_POINT_ALIGNMENT': {
                'pivotPoint': self.pivot_point
            },
            'DRACO_COMPRESSION': {'enabled': self.draco_compression},
            'OUTPUT_LAYER': {'fbxPbr': self.fbx_pbr_textures},
        }

        if self.model_scaling:
            size = self.size
            if self.unit == 'cm':
                size *= 0.01
            elif self.unit == 'in':
                size *= 0.0254
            params['AR_SCALING'] = {
                'dimension': self.axis_to_scale_on, 'size': size}

        if self.geometry_optimization:
            params['OPTIMIZATION'] = {
                'desiredOutput': 'AUTO',
                'obstructedGeometry': self.remove_obstructed_geometry,
                'bakeSmallFeatures': self.small_feature_baking,
                'poly': self.polygon_limit,
                'forcePolygonCount': self.force_polygon_count,
                'freezeTransforms': self.freeze_transforms
            }
        else:
            params['OPTIMIZATION'] = {}

        if self.texture_compression:
            params['TEXTURE_COMPRESSION'] = {
                'useKTX': self.use_ktx,
                'bakeAmbientOcclusion': self.bake_ambient_occlusion,
                'ambientOcclusionStrength': self.ao_strength,
                'ambientOcclusionRadius': self.ao_radius,
                'ambientOcclusionResolution': self.ao_resolution,
                'maxDimension': self.max_texture_dimension,
                'aggression': self.texture_compression,  # String "1"-"5" per API
                'lossless': 'false'
            }
            if self.file_size_limit:
                params['TEXTURE_COMPRESSION']['fileSizeLimit'] = self.file_size_limit_in_mb
                params['TEXTURE_COMPRESSION']['forceFileSizeLimit'] = self.force_file_size_limit
        else:
            params['TEXTURE_COMPRESSION'] = {}

        return params


def register():
    """Register export properties."""
    bpy.utils.register_class(VNTANATag)
    bpy.utils.register_class(VNTANAAttribute)
    bpy.utils.register_class(VNTANAExportSettings)


def unregister():
    """Unregister export properties."""
    bpy.utils.unregister_class(VNTANAExportSettings)
    bpy.utils.unregister_class(VNTANATag)
    bpy.utils.unregister_class(VNTANAAttribute)
