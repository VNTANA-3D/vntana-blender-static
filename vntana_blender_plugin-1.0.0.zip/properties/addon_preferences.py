# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Addon Preferences

import bpy
import os
from bpy.props import (
    BoolProperty,
    StringProperty,
    EnumProperty,
    PointerProperty,
    CollectionProperty
)
from bpy.types import AddonPreferences

from ..api import get_async_api
from ..core import get_preferences, tag_redraw
from .export_properties import *


def update_base_url(self, context):
    get_async_api().base_url = self.base_url


def update_debug_logging(self, context):
    """Apply logging level changes immediately."""
    from ..core.logger import set_debug_logging
    set_debug_logging(self.enable_debug_logging)


# These are needed, so that strings don't get GC-ed per Blender's documentation
pipeline_cache = []
optimization_presets_cache = []
viewer_presets_cache = []


def get_pipelines(self, context):
    api = get_async_api()
    pipeline_cache = [(pipeline.get('uuid', ''), pipeline.get('name', ''), '')
                      for pipeline in api.pipelines]
    return pipeline_cache


def get_optimization_presets(self, context):
    api = get_async_api()
    optimization_presets_cache = [(preset.get('uuid', 'None'), preset.get('name', 'None'), '')
                                  for preset in api.optimization_presets]
    return optimization_presets_cache


def get_viewer_presets(self, context):
    api = get_async_api()
    viewer_presets_cache = [(preset.get('uuid', 'None'), preset.get('name', 'None'), '')
                            for preset in api.viewer_presets]
    return viewer_presets_cache


def update_pipeline(self, context):
    self.property_unset("export_settings")
    self.property_unset('optimization_presets')
    tag_redraw(context)


# Returns pair (success, result)
def parse_bool(str):
    strlc = str.lower()
    if strlc == 'true':
        return True, True
    if strlc == 'false':
        return True, False
    return False, False


def parse_int(str):
    try:
        val = int(str)
    except:
        return False, 0
    return True, val


def parse_float(str):
    result = False
    try:
        val = float(str)
    except:
        return False, 0
    return True, val


def update_opt_preset(self, context):
    self.property_unset("export_settings")
    api = get_async_api()
    for preset in api.optimization_presets:
        if preset.get('uuid', '') == self.optimization_presets:
            # NOTE(ivan): we need to override the default export properties with optimization presets.
            # Unfortunately, this is a giant mess, all values are strings, ints can be 'null' etc.
            mops = preset.get('modelOpsParameters', {})
            draco = mops.get('DRACO_COMPRESSION', {})
            parsed, val = parse_bool(draco.get('enabled', ''))
            if parsed:
                self.export_settings.draco_compression = val

            if 'OPTIMIZATION' in mops:
                opt = mops.get('OPTIMIZATION') or {}
                parsed, val = parse_bool(opt.get('obstructedGeometry', ''))
                if parsed:
                    self.export_settings.remove_obstructed_geometry = val
                parsed, val = parse_int(opt.get('poly', int))
                if parsed:
                    self.export_settings.polygon_limit = val
                parsed, val = parse_bool(opt.get('forcePolygonCount', ''))
                if parsed:
                    self.export_settings.force_polygon_count = val
                parsed, val = parse_bool(opt.get('bakeSmallFeatures', ''))
                if parsed:
                    self.export_settings.small_feature_baking = val
                if parsed:
                    self.export_settings.force_file_size_limit = val
                parsed, val = parse_bool(opt.get('freezeTransforms', ''))
                if parsed:
                    self.export_settings.freeze_transforms = val

            if 'PIVOT_POINT_ALIGNMENT' in mops:
                ppa = mops['PIVOT_POINT_ALIGNMENT'] or {}
                try:
                    self.export_settings.pivot_point = ppa.get(
                        'pivotPoint', '')
                except:
                    pass
            if 'AR_SCALING' in mops:
                ar_scaling = mops['AR_SCALING'] or {}
                try:
                    self.export_settings.axis_to_scale_on = ar_scaling.get(
                        'dimension', '').upper()
                    self.export_settings.model_scaling = True
                except:
                    pass
                parsed, val = parse_float(ar_scaling.get('size', ''))
                if parsed:
                    self.export_settings.size = val

            if 'TEXTURE_COMPRESSION' in mops:
                tex_compression = mops['TEXTURE_COMPRESSION'] or {}
                parsed, val = parse_float(
                    tex_compression.get('fileSizeLimit', ''))
                if parsed:
                    self.export_settings.file_size_limit = True
                    self.export_settings.file_size_limit_in_mb = val
                parsed, val = parse_bool(
                    tex_compression.get('forceFileSizeLimit', ''))
                parsed, val = parse_bool(tex_compression.get('lossless', ''))
                if parsed and val:
                    self.export_settings.texture_compression = '0'

                try:
                    self.export_settings.max_texture_dimension = tex_compression.get(
                        'maxDimension', '')
                except:
                    pass

                try:
                    self.export_settings.texture_compression = tex_compression.get(
                        'aggression', '')
                except:
                    pass
                parsed, val = parse_bool(tex_compression.get('useKTX', ''))
                if parsed:
                    self.export_settings.use_ktx = val
                parsed, val = parse_bool(
                    tex_compression.get('bakeAmbientOcclusion', ''))
                if parsed:
                    self.export_settings.bake_ambient_occlusion = val
                parsed, val = parse_int(tex_compression.get(
                    'ambientOcclusionStrength', ''))
                if parsed:
                    self.export_settings.ao_strength = val
                parsed, val = parse_int(
                    tex_compression.get('ambientOcclusionRadius', ''))
                if parsed:
                    self.export_settings.ao_radius = val
                try:
                    self.export_settings.ao_resolution = tex_compression.get(
                        'ambientOcclusionResolution', '')
                except:
                    pass
            # TODO(ivan): check if this is correct
            if 'OUTPUT_LAYER' in mops:
                output_layer = mops['OUTPUT_LAYER'] or {}
                parsed, val = parse_bool(output_layer.get('fbxPbr', ''))
                if parsed:
                    self.export_settings.fbx_pbr_textures = val

    tag_redraw(context)


def on_page_size_change(self, context):
    """Handle page size selection change."""
    import bpy
    # Trigger search with new page size
    if bpy.ops.vntana.search_assets.poll():
        prefs = get_preferences().preferences
        bpy.ops.vntana.search_assets('INVOKE_DEFAULT')


def on_search_term_change(self, context):
    """Handle search term change - triggers search when user presses Enter or clicks away."""
    import bpy
    if bpy.ops.vntana.search_assets.poll():
        prefs = get_preferences().preferences
        bpy.ops.vntana.search_assets('INVOKE_DEFAULT')


class VNTANAAssetItem(PropertyGroup):
    """Represents an asset in the asset browser."""

    uuid: StringProperty(
        name="UUID",
        description="Asset UUID",
        default=""
    )

    name: StringProperty(
        name="Name",
        description="Asset name",
        default=""
    )

    description: StringProperty(
        name="Description",
        description="Asset description",
        default=""
    )

    optimization_status: StringProperty(
        name="Optimization Status",
        description="Optimization status",
        default="NO_ASSET"
    )

    thumbnail_blob_id: StringProperty(
        name="Thumbnail Blob ID",
        description="Thumbnail blob ID for downloading",
        default=""
    )

    updated_at: StringProperty(
        name="Updated At",
        description="Last update timestamp",
        default=""
    )

    tags: CollectionProperty(
        name="Tags",
        type=VNTANATag
    )

    attributes: CollectionProperty(
        name="Attributes",
        type=VNTANAAttribute
    )


class VNTANAUIState(PropertyGroup):
    # =========================================================================
    # UI State
    # =========================================================================

    # Login form fields (temporary, not saved to .blend files)
    login_email: StringProperty(
        name="Email",
        description="Email address",
        default=""
    )

    login_password: StringProperty(
        name="Password",
        description="Password",
        default="",
        subtype='PASSWORD'
    )

    login_pat: StringProperty(
        name="Key",
        description="Authentication key.",
        default="",
        subtype='PASSWORD'
    )

    # =========================================================================
    # Import/Browser State
    # =========================================================================

    assets: CollectionProperty(
        name="Assets",
        type=VNTANAAssetItem
    )

    active_asset_index: IntProperty(
        name="Active Asset Index",
        description="Index of selected asset in browser",
        default=0
    )

    active_attribute_index: IntProperty(
        name="Active Attribute Index",
        description="Index of selected attribute on the active asset",
        default=0
    )

    asset_search_term: StringProperty(
        name="Search",
        description="Search assets by name",
        default="",
        update=on_search_term_change
    )

    current_page: IntProperty(
        name="Current Page",
        description="Current page in asset browser",
        default=1,
        min=1
    )

    total_assets: IntProperty(
        name="Total Assets",
        description="Total number of assets",
        default=0
    )

    # =========================================================================
    # Operation State
    # =========================================================================
    operation_message: StringProperty(
        name="Operation Message",
        description="Current operation status message",
        default=""
    )

    operation_progress: FloatProperty(
        name="Operation Progress",
        description="Current operation progress",
        default=0,
    )

    download_progress: FloatProperty(
        name="Download progress",
        description="Download progress.",
        default=-1
    )

    export_progress: FloatProperty(
        name="Export progress",
        description="Export progress.",
        default=-1
    )

    asset_name: StringProperty(
        name="Asset Name",
        description="Name for the asset in VNTANA (defaults to blend file name)",
        default="",
        maxlen=MAX_ASSET_NAME_LENGTH,
        update=update_asset_name
    )

    description: StringProperty(
        name="Description",
        description="Asset description",
        default="",
        maxlen=MAX_DESCRIPTION_LENGTH
    )

    export_selected: BoolProperty(
        name="Selected Only",
        description="Export only selected objects",
        default=False
    )

    apply_modifiers: BoolProperty(
        name="Apply Modifiers",
        description="Apply modifiers to exported meshes",
        default=True
    )

    export_animations: BoolProperty(
        name="Export Animations",
        description="Include animations in the export",
        default=True
    )

    tags: CollectionProperty(
        name="Tags",
        type=VNTANATag
    )
    attributes: CollectionProperty(
        name="Attributes",
        type=VNTANAAttribute
    )
    pipelines: EnumProperty(
        name="Pipeline",
        description="Optimization pipeline.",
        items=get_pipelines,
        update=update_pipeline)
    viewer_presets: EnumProperty(
        name="Viewer Presets",
        description="Viewer presets.",
        items=get_viewer_presets
    )
    optimization_presets: EnumProperty(
        name="Optimization Presets",
        description="Optimization presets.",
        items=get_optimization_presets,
        update=update_opt_preset
    )
    export_settings: PointerProperty(
        name="Export Settings",
        type=VNTANAExportSettings,
        options={'SKIP_SAVE'}
    )


class VNTANAPreferences(AddonPreferences):
    """Addon preferences for VNTANA plugin."""

    from ..core import get_addon_id
    bl_idname = get_addon_id()
    # =========================================================================
    # Auto-Login Settings
    # =========================================================================

    enable_auto_login: BoolProperty(
        name="Enable Auto-Login",
        description="Automatically log in with stored credentials when Blender starts",
        default=True
    )

    base_url: StringProperty(
        name="Base URL",
        description="Base URL to use for all network requests.",
        default="https://api-platform.vntana.com",
        update=update_base_url
    )

    # =========================================================================
    # Logging
    # =========================================================================

    enable_debug_logging: BoolProperty(
        name="Enable Debug Logging",
        description="Enable detailed debug logging",
        default=False,
        update=update_debug_logging
    )

    last_organization: StringProperty(
        name="Organization UUID",
        description="Last accessed organization UUID used to restore a session.",
        default=""
    )

    last_workspace: StringProperty(
        name="Workspace UUID",
        description="Last accessed workspace UUID used to restore a session.",
        default=""
    )

    import_folder: StringProperty(
        name="Import Folder",
        description="Import folder where downloaded models are saved.",
        default=os.path.join(os.path.expanduser('~'), 'downloads')
    )

    ui: PointerProperty(
        name="UI State",
        type=VNTANAUIState,
        options={'SKIP_SAVE'}
    )

    login_method: EnumProperty(
        name="Login Method",
        description="Authentication method",
        items=[
            ('PAT', 'Authentication Key', 'Login with Authentication Key.'),
            ('CREDENTIALS', 'Email & Password',
             'Login with email and password'),
        ],
        default='PAT'
    )

    remember_pat: BoolProperty(
        name="Remember",
        description="Store token for automatic login",
        default=True
    )

    asset_view_mode: EnumProperty(
        name="View Mode",
        description="Asset browser view mode",
        items=[
            ('LIST', "List", "Show assets as a list", 'COLLAPSEMENU', 0),
            ('GRID', "Grid", "Show assets as a thumbnail grid", 'IMGDISPLAY', 1),
        ],
        default='LIST'
    )

    page_size_enum: EnumProperty(
        name="Page Size",
        description="Number of assets per page",
        items=[
            ('12', "12", "Show 12 assets per page"),
            ('24', "24", "Show 24 assets per page"),
            ('48', "48", "Show 48 assets per page"),
        ],
        default='12',
        update=on_page_size_change
    )

    def draw(self, context):
        """Draw the addon preferences UI."""
        layout = self.layout

        box = layout.box()
        if not get_async_api().is_authenticated():
            box.prop(self, "base_url")

        # Security & Privacy Settings
        box.prop(self, "enable_auto_login")

        # Logging
        box = layout.box()
        box.label(text="Logging", icon='TEXT')
        box.prop(self, "enable_debug_logging")

        level_label = "DEBUG" if self.enable_debug_logging else "INFO"
        box.label(text=f"Active log level: {level_label}", icon='INFO')

        from ..core.logger import get_log_path
        log_path = get_log_path()
        box.label(text=f"Log file: {log_path}", icon='FILE')


def register():
    """Register addon preferences."""
    bpy.utils.register_class(VNTANAAssetItem)
    bpy.utils.register_class(VNTANAUIState)
    bpy.utils.register_class(VNTANAPreferences)


def unregister():
    """Unregister addon preferences."""
    bpy.utils.unregister_class(VNTANAAssetItem)
    bpy.utils.unregister_class(VNTANAUIState)
    bpy.utils.unregister_class(VNTANAPreferences)
