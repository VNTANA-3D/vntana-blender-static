# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Properties Module

from .addon_preferences import VNTANAPreferences
from .export_properties import VNTANAExportSettings

__all__ = ['VNTANAPreferences',
           'VNTANASceneProperties', 'VNTANAExportSettings']


def register():
    """Register all property classes."""
    import bpy

    from .export_properties import register as register_export
    from .addon_preferences import register as register_prefs

    register_export()
    register_prefs()


def unregister():
    """Unregister all property classes."""
    from .addon_preferences import unregister as unregister_prefs
    from .export_properties import unregister as unregister_export

    unregister_prefs()
    unregister_export()
