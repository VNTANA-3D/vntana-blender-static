# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Import Operators

import bpy
import os
import tempfile
import asyncio
from pathlib import Path
from bpy.types import Operator
from bpy.props import StringProperty, IntProperty, EnumProperty

from ..api.vnt_api_async import get_async_api
from ..core.logger import get_logger
from ..core import create_task, tag_redraw, get_thumbnail_cache_directory, get_preferences

from .operator_utils import *
from .. import get_icons


def draw_import_failed(self, context):
    self.layout.label(text="Import failed.")


async def download_thumbnail(api, blob_id):
    icons = get_icons()
    if blob_id and blob_id not in icons.thumbnail_state:
        icons.thumbnail_state[blob_id] = 'DOWNLOADING'
        success, image_data, error = await api.download_thumbnail(blob_id)
        if success and image_data:
            image_path = get_thumbnail_cache_directory() / blob_id
            try:
                with open(image_path, 'wb') as f:
                    f.write(image_data)
                    icons.preview_collections.load(
                        blob_id, str(image_path), 'IMAGE')
                    icons.thumbnail_state[blob_id] = 'CACHED'
            except Exception as e:
                print(e)
                pass
        # TODO(ivan): do we need to retry?
        if icons.thumbnail_state[blob_id] != 'CACHED':
            icons.thumbnail_state.pop(blob_id)


async def download_thumbnails(api, blob_ids):
    await asyncio.gather(*[download_thumbnail(api, blob_id) for blob_id in blob_ids])


class VNTANA_OT_download_thumbnails(Operator):
    bl_idname = "vntana.download_thumbnails"
    bl_label = "Download Thumbnails"
    bl_description = "Download thumbnail images for displayed assets"
    bl_options = {'REGISTER', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return bpy.app.online_access

    def execute(self, context):
        vntana = get_preferences().preferences.ui
        blob_ids = [asset.thumbnail_blob_id for asset in vntana.assets]
        self._task = create_task(
            download_thumbnails(get_async_api(), blob_ids))
        add_timer(self, context)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        status = {'PASS_THROUGH'}

        if event.type == 'TIMER':
            tag_redraw(context)
            if self._task and self._task.done():
                remove_timer(self, context)
                status = {'FINISHED'}

        return status


class VNTANA_OT_search_assets(VNTANA_OT_async_operator):
    """Search for assets in VNTANA"""
    bl_idname = "vntana.search_assets"
    bl_label = "Search Assets"
    bl_description = "Search for assets in the current workspace"
    bl_options = {'REGISTER', 'INTERNAL'}

    page: IntProperty(
        name="Page",
        default=1  # API uses 1-indexed pages
    )

    @classmethod
    def poll(cls, context):
        if VNTANA_OT_async_operator.poll(context):
            auth = get_async_api()
            return auth.is_authenticated() and auth.client_uuid
        return False

    def execute(self, context):
        prefs = get_preferences().preferences
        vntana = prefs.ui
        vntana.operation_message = "Searching assets"
        vntana.current_page = self.page
        self._task = create_task(get_async_api().search_assets(
            page=self.page,
            size=int(prefs.page_size_enum),
            search_term=vntana.asset_search_term
        ))

        add_timer(self, context)
        return {'RUNNING_MODAL'}

    def on_finish(self, context):
        if self._task and self._task.done():
            res = self._task.result()
            assets = res.data['response']['grid']
            total_assets = res.data['response']['totalCount']
            vntana = get_preferences().preferences.ui
            vntana.assets.clear()
            vntana.total_assets = total_assets
            for asset_data in assets:
                item = vntana.assets.add()
                item.uuid = asset_data.get('uuid', '')
                item.name = asset_data.get('name', 'Untitled')
                item.description = asset_data.get('description', '') or ''
                item.optimization_status = asset_data.get(
                    'conversionStatus', 'NO_ASSET')
                # thumbnailBlobId is nested inside 'asset' object
                asset_obj = asset_data.get('asset', {})
                for tag in asset_data.get('tags', []):
                    name = tag.get('name', '')
                    if name:
                        ui_tag = item.tags.add()
                        ui_tag.name = name
                for attr in asset_data.get('attributes', []):
                    ui_attr = item.attributes.add()
                    ui_attr.name = attr.get('key', '')
                    ui_attr.value = attr.get('value', '')
                if asset_obj:
                    thumbnail_blob_id = asset_obj.get(
                        'thumbnailBlobId', '')
                    item.thumbnail_blob_id = thumbnail_blob_id or ''
                item.updated_at = asset_data.get(
                    'updated', '')

            bpy.ops.vntana.download_thumbnails('INVOKE_DEFAULT')


class VNTANA_OT_select_asset(Operator):
    """Select an asset in grid view"""
    bl_idname = "vntana.select_asset"
    bl_label = "Select Asset"
    bl_description = "Select this asset"
    bl_options = {'REGISTER', 'INTERNAL'}

    index: IntProperty(
        name="Index",
        default=0
    )

    def execute(self, context):
        vntana = get_preferences().preferences.ui
        if 0 <= self.index < len(vntana.assets):
            vntana.active_asset_index = self.index
        return {'FINISHED'}


class VNTANA_OT_import_asset(VNTANA_OT_async_operator):
    """Import asset from VNTANA"""
    bl_idname = "vntana.import_asset"
    bl_label = "Import Asset"
    bl_description = "Download and import the selected asset"
    bl_options = {'REGISTER'}

    asset_uuid: StringProperty(
        name="Asset UUID",
        default=""
    )

    asset_name: StringProperty(
        name="Asset name",
        default=""
    )

    @classmethod
    def poll(cls, context):
        result = False
        if VNTANA_OT_async_operator.poll(context):
            auth = get_async_api()
            if auth.is_authenticated() and auth.client_uuid:
                result = True

        return result

    def execute(self, context):
        self.model_file_path = ""

        logger = get_logger()
        vntana = get_preferences().preferences.ui

        status = {'CANCELLED'}
        # Get asset UUID from property or selection
        if self.asset_uuid:
            vntana.operation_message = "Downloading asset"
            vntana.operation_progress = 0
            logger.info(f"Starting import for asset: {self.asset_uuid}")
            self._task = create_task(self._do_import(self.asset_uuid))
            add_timer(self, context)
            status = {'RUNNING_MODAL'}

        return status

    def on_finish(self, context):
        get_preferences().preferences.ui.download_progress = -1
        if self._task and self._task.done():
            res, errs = self._task.result()
            if not res:
                get_logger().error(str(errs))
                context.window_manager.popup_menu(
                    draw_import_failed, title='VNTANA', icon='ERROR')
            elif bpy.ops.import_scene.gltf.poll():
                bpy.ops.import_scene.gltf(
                    'INVOKE_DEFAULT', filepath=str(self.model_file_path))

    async def _do_import(self, asset_uuid: str) -> dict:
        """Download asset asynchronously."""
        from ..api.vnt_api_async import get_async_api

        logger = get_logger()
        api = get_async_api()

        try:
            def on_progress(downloaded, total):
                vntana = get_preferences().preferences.ui
                vntana.download_progress = downloaded / total if total > 0 else 0

            success, file_data, error = await api.download_optimized_model(
                asset_uuid,
                conversion_format="GLB",
                progress_callback=on_progress
            )

            if not success:
                return False, [error or 'Download failed']

            downloads_dir = get_preferences().preferences.import_folder
            model_file_path = Path(downloads_dir) / (self.asset_name + ".glb")
            with open(model_file_path, "wb") as f:
                f.write(file_data)

            logger.info(
                f"Downloaded to: {model_file_path} ({len(file_data)} bytes)")

            self.model_file_path = model_file_path

            return True, []

        except Exception as e:
            logger.exception(f"Download failed: {e}")
            return False, [str(e)]


# Registration
classes = [
    VNTANA_OT_search_assets,
    VNTANA_OT_download_thumbnails,
    VNTANA_OT_select_asset,
    VNTANA_OT_import_asset,
]


def register():
    """Register import operators."""
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    """Unregister import operators."""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
