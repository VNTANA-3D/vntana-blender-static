from ..core import tag_redraw, get_preferences

from bpy.types import Operator


def add_timer(operator, context):
    wm = context.window_manager
    operator._timer = wm.event_timer_add(0.1, window=context.window)
    wm.modal_handler_add(operator)


def remove_timer(operator, context):
    if operator._timer:
        wm = context.window_manager
        wm.event_timer_remove(operator._timer)
        operator._timer = None


def is_operator_done(status):
    return status == {'FINISHED'} or status == {'CANCELLED'}


class VNTANA_OT_async_operator(Operator):
    @classmethod
    def poll(cls, context):
        import bpy
        if bpy.app.online_access:
            ui = get_preferences().preferences.ui
            return not ui.operation_message
        return False

    def modal(self, context, event):
        status = {'PASS_THROUGH'}

        if event.type == 'TIMER':
            tag_redraw(context)
            vntana = get_preferences().preferences.ui
            vntana.operation_progress += self._timer.time_step

            if self._task and self._task.done():
                exc = self._task.exception()
                if exc:
                    self.report({'ERROR'}, f"Operation failed: {exc}")

                status = {'FINISHED'}

            elif not self._task:
                status = {'FINISHED'}

        elif event.type == 'ESC':
            status = {'CANCELLED'}

        if is_operator_done(status):
            self.finish(context)

        return status

    def finish(self, context):
        if self._task and not self._task.done():
            self._task.cancel()

        remove_timer(self, context)
        ui = get_preferences().preferences.ui
        ui.operation_message = ""
        ui.operation_progress = 0

        if hasattr(self, 'on_finish'):
            self.on_finish(context)
