# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Export Operators

import bpy
import os
import tempfile
import asyncio
from pathlib import Path
from bpy.types import Operator
from bpy.props import PointerProperty, StringProperty, EnumProperty, IntProperty

from ..api.vnt_api_async import get_async_api
from ..core.logger import get_logger
from ..core import create_task, get_preferences
from .operator_utils import add_timer, remove_timer, tag_redraw
from ..properties import VNTANAExportSettings
from .operator_utils import *


def draw_upload_success(self, context):
    self.layout.label(text="Upload succeeded.")


def draw_upload_failed(self, context):
    self.layout.label(text="Upload failed.")


def update_upload_progress(readCount, total):
    if get_preferences().preferences.ui.operation_message:
        get_preferences().preferences.ui.export_progress = readCount / total


async def get_or_create_tag_uuid(api, tag):
    for cached_tag in api.tags:
        if cached_tag.get('name', '') == tag:
            return cached_tag.get('uuid', '')

    uuid = await api.get_tag_uuid(tag)
    if not uuid:
        uuid = await api.create_tag(tag)

    return uuid


class VNTANA_OT_export(VNTANA_OT_async_operator):
    """Export to VNTANA platform"""
    bl_idname = "vntana.export"
    bl_label = "Export to VNTANA"
    bl_description = "Export the scene/selection to VNTANA platform"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        result = False
        if VNTANA_OT_async_operator.poll(context):
            auth = get_async_api()
            prefs = get_preferences().preferences
            if auth.is_authenticated() and auth.client_uuid:
                if prefs.ui.export_selected:
                    result = len(context.selected_objects) > 0
                else:
                    for obj in context.scene.objects:
                        if obj.type == 'MESH':
                            result = True
                            break
        return result

    def execute(self, context):
        self._timer = None
        self._task = None
        self._temp_file = None
        self._temp_dir = None

        logger = get_logger()
        prefs = get_preferences().preferences
        vntana = prefs.ui
        export_settings = prefs.ui.export_settings

        asset_name = vntana.asset_name.strip()
        if not asset_name:
            if bpy.data.filepath:
                asset_name = Path(bpy.data.filepath).stem
            else:
                asset_name = context.scene.name or "Untitled"

        logger.info(f"Starting export: {asset_name}")
        vntana.operation_message = "Preparing export"

        try:
            self._temp_dir = tempfile.mkdtemp(prefix="vntana_export_")
            fd, temp_file = tempfile.mkstemp(suffix=".glb", dir=self._temp_dir)
            os.close(fd)

            logger.info(f"Exporting GLB to: {temp_file}")

            bpy.ops.export_scene.gltf(
                filepath=temp_file,
                export_format='GLB',
                use_selection=prefs.ui.export_selected,
                export_apply=prefs.ui.apply_modifiers,
                export_yup=True,
                export_animations=prefs.ui.export_animations,
                export_draco_mesh_compression_enable=False,
            )

            if not os.path.exists(temp_file):
                raise RuntimeError("GLB export failed - no file created")

            self._temp_file = temp_file
        except Exception as e:
            logger.exception(f"GLB export failed: {e}")
            self.report({'ERROR'}, f"Export failed: {e}")
            vntana.operation_message = ""
            return {'CANCELLED'}

        vntana.operation_message = "Uploading to VNTANA"

        unique_tags = list(
            set([tag.name for tag in vntana.tags if tag.name]))

        attributes = {}
        for attr in vntana.attributes:
            if attr.name and attr.value:
                attributes[attr.name] = attr.value

        # Prepare upload data
        upload_data = {
            'file_path': self._temp_file,
            'asset_name': asset_name,
            'model_ops_parameters': export_settings.get_model_ops_parameters(),
            'description': vntana.description,
            'tags': unique_tags,
            'attributes': attributes,
            'publish_to_status': export_settings.publish_to_status,
            'optimization_preset_uuid': prefs.ui.optimization_presets if prefs.ui.optimization_presets != 'None' else '',
            'viewer_preset_uuid': prefs.ui.viewer_presets if prefs.ui.viewer_presets != 'None' else '',
            'pipeline_uuid': prefs.ui.pipelines,
        }

        # Start async upload
        self._task = create_task(self._do_upload_async(upload_data))

        get_preferences().preferences.ui.export_progress = 0

        add_timer(self, context)

        tag_redraw(context)

        return {'RUNNING_MODAL'}

    def on_finish(self, context):
        # Clean up temp file
        if self._temp_file and os.path.exists(self._temp_file):
            try:
                os.unlink(self._temp_file)
            except OSError as e:
                get_logger().warning(
                    f"Failed to delete temp file {self._temp_file}: {e}")
        self._temp_file = None

        # Clean up temp directory
        if self._temp_dir and os.path.isdir(self._temp_dir):
            try:
                os.rmdir(self._temp_dir)
            except OSError as e:
                get_logger().warning(
                    f"Failed to delete temp directory {self._temp_dir}: {e}")
        self._temp_dir = None

        if self._task and self._task.done():
            res, errs = self._task.result()
            if res:
                context.window_manager.popup_menu(
                    draw_upload_success, title='VNTANA', icon='INFO')
            else:
                get_logger().error(str(errs))
                context.window_manager.popup_menu(
                    draw_upload_failed, title='VNTANA', icon='ERROR')

        get_preferences().preferences.ui.export_progress = -1

    async def _do_upload_async(self, upload_data: dict) -> dict:
        from ..api.vnt_api_async import get_async_api

        logger = get_logger()
        api = get_async_api()

        file_path = upload_data['file_path']
        asset_name = upload_data['asset_name']
        model_ops = upload_data['model_ops_parameters']

        try:
            # TODO(ivan): it might be better to stream directly from disk instead of loading the whole file to memory synchronously
            with open(file_path, 'rb') as f:
                file_data = f.read()

            file_size = len(file_data)
            filename = f"{asset_name}.glb"

            # Get preset and pipeline UUIDs
            opt_preset_uuid = upload_data.get('optimization_preset_uuid')
            viewer_preset_uuid = upload_data.get('viewer_preset_uuid')
            pipeline_uuid = upload_data.get('pipeline_uuid')
            tags = upload_data.get('tags')

            tag_tasks = [asyncio.create_task(
                get_or_create_tag_uuid(api, tag)) for tag in tags if tag]
            await asyncio.gather(*tag_tasks)

            tag_uuids = [task.result() for task in tag_tasks if task.result()]

            # Create the asset
            create_response = await api.create_asset(
                name=asset_name,
                model_ops_parameters=model_ops,
                description=upload_data.get('description', ''),
                publish_to_status=upload_data.get(
                    'publish_to_status', 'DRAFT'),
                preset_uuid=opt_preset_uuid,
                viewer_preset_uuid=viewer_preset_uuid,
                pipeline_uuid=pipeline_uuid,
                tags_uuids=tag_uuids,
                attributes=upload_data.get('attributes', {})
            )

            if not create_response.success:
                return (False, create_response.errors)

            # Get the product UUID
            product_uuid = create_response.data.get('response', {}).get('uuid')
            if not product_uuid:
                return (False, ['No product UUID in response'])

            logger.info(f"Asset created with UUID: {product_uuid}")

            # Get signed upload URL
            sign_response = await api.get_signed_upload_url(
                product_uuid=product_uuid,
                filename=filename,
                file_size=file_size
            )

            if not sign_response.success:
                return (False, sign_response.errors)

            signed_url = sign_response.data.get('response', {}).get('location')
            if not signed_url:
                return (False, ['No signed URL in response'])

            logger.info("Uploading file to signed URL...")

            # Upload the file
            upload_response = await api.upload_file(signed_url, file_data, update_upload_progress)

            if not upload_response.success:
                return (False, upload_response.errors or ['Upload failed'])

            logger.info("Upload complete!")

            return (True, [])

        except Exception as e:
            logger.exception(f"Upload failed: {str(e)}")
            return (False, [str(e)])


class VNTANA_OT_reset_export_settings(Operator):
    """Reset export settings to defaults"""
    bl_idname = "vntana.reset_export_settings"
    bl_label = "Reset Export Settings"
    bl_description = "Reset all export settings to their default values"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        get_preferences().preferences.ui.property_unset("export_settings")
        return {'FINISHED'}


class VNTANA_OT_add_tag(Operator):
    bl_idname = "vntana.add_tag"
    bl_label = "Add Tag"
    bl_description = "Add Tag."
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        get_preferences().preferences.ui.tags.add()
        return {'FINISHED'}


class VNTANA_OT_remove_tag(Operator):
    bl_idname = "vntana.remove_tag"
    bl_label = "Remove Tag"
    bl_description = "Remove Tag."
    bl_options = {'REGISTER', 'INTERNAL'}

    index: IntProperty(
        name="Index",
        default=0
    )

    def execute(self, context):
        ui = get_preferences().preferences.ui
        if self.index >= 0 and self.index < len(ui.tags):
            ui.tags.remove(self.index)
        return {'FINISHED'}


class VNTANA_OT_add_attribute(Operator):
    bl_idname = "vntana.add_attribute"
    bl_label = "Add Attribute"
    bl_description = "Add attribute."
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        get_preferences().preferences.ui.attributes.add()
        return {'FINISHED'}


class VNTANA_OT_remove_attribute(Operator):
    bl_idname = "vntana.remove_attribute"
    bl_label = "Remove Attribute"
    bl_description = "Remove attribute."
    bl_options = {'REGISTER', 'INTERNAL'}

    index: IntProperty(
        name="Index",
        default=0
    )

    def execute(self, context):
        ui = get_preferences().preferences.ui
        if self.index >= 0 and self.index < len(ui.attributes):
            ui.attributes.remove(self.index)
        return {'FINISHED'}


# Registration
classes = [
    VNTANA_OT_export,
    VNTANA_OT_reset_export_settings,
    VNTANA_OT_add_tag,
    VNTANA_OT_remove_tag,
    VNTANA_OT_add_attribute,
    VNTANA_OT_remove_attribute,
]


def register():
    """Register export operators."""
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    """Unregister export operators."""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
