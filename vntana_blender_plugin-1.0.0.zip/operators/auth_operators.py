# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Authentication Operators

import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty

from ..api.vnt_api_async import get_async_api
from ..core.logger import get_logger
from ..core import create_task
from .operator_utils import *

import asyncio

from ..core import credentials


def select_by_uuid(last_uuid, items):
    res_item = {}
    if len(items) == 1:
        res_item = items[0]
    elif last_uuid:
        for organization in items:
            if organization.get('uuid', '') == last_uuid:
                res_item = organization

    return res_item


async def get_presets(api):
    await asyncio.gather(api.get_pipelines(), api.get_viewer_presets(), api.get_optimization_presets(), api.search_tags())


async def select_ws(api, ws_uuid):
    workspaces = api.workspaces
    selected_ws = select_by_uuid(ws_uuid, workspaces)
    await api.select_workspace(selected_ws)
    if api.client_uuid:
        get_preferences().preferences.last_workspace = api.client_uuid
        await get_presets(api)


async def select_org(api, org_uuid, ws_uuid):
    selected_org = select_by_uuid(org_uuid, api.organizations)

    res = await api.select_organization(selected_org)

    if res and res.success:
        get_preferences().preferences.last_organization = api.organization_uuid
        res = await api.get_workspaces()

    await select_ws(api, ws_uuid)


async def login_flow(pat, username, password, last_organization_uuid, last_workspace_uuid, store_pat):
    api = get_async_api()
    if pat:
        res = await api.login_with_pat(pat)
        if res.success and store_pat:
            if not credentials.cred_write('vnt-plugin', pat, 'pat'):
                get_logger().warning("Failed to store credentials.")
    else:
        res = await api.login_with_credentials(username, password)

    if res.success:
        await api.get_organizations()
        await select_org(api, last_organization_uuid, last_workspace_uuid)


class VNTANA_OT_login(VNTANA_OT_async_operator):
    """Login to VNTANA platform"""
    bl_idname = "vntana.login"
    bl_label = "Login"
    bl_description = "Login to VNTANA platform"
    bl_options = {'REGISTER', 'INTERNAL'}

    pat: StringProperty(
        name="Personal Access Token",
        default="",
        options={"SKIP_SAVE"}
    )

    username: StringProperty(
        name="Username",
        default="",
        options={"SKIP_SAVE"}
    )

    password: StringProperty(
        name="Password",
        default="",
        options={"SKIP_SAVE"}
    )

    def execute(self, context):
        running = False
        prefs = get_preferences().preferences
        vntana = prefs.ui
        if self.pat or (self.username and self.password):
            self._task = create_task(login_flow(
                self.pat, self.username, self.password, prefs.last_organization, prefs.last_workspace, prefs.remember_pat))
            vntana.operation_message = "Logging in"
            add_timer(self, context)
            running = True

        return {'RUNNING_MODAL'} if running else {'FINISHED'}

    def on_finish(self, context):
        context.preferences.is_dirty = True
        if bpy.ops.vntana.search_assets.poll():
            bpy.ops.vntana.search_assets('INVOKE_DEFAULT')


class VNTANA_OT_logout(VNTANA_OT_async_operator):
    """Logout from VNTANA platform"""
    bl_idname = "vntana.logout"
    bl_label = "Logout"
    bl_description = "Logout from VNTANA platform"
    bl_options = {'REGISTER', 'INTERNAL'}

    base_url: StringProperty(
        name="Base url",
        default="",
        options={"SKIP_SAVE"}
    )

    def execute(self, context):
        self._task = create_task(get_async_api().logout())

        vntana = get_preferences().preferences.ui
        vntana.operation_message = "Logging out"
        # Update UI state
        if not get_preferences().preferences.remember_pat:
            vntana.login_pat = ""
        vntana.login_password = ""

        # Clear assets
        vntana.assets.clear()
        vntana.current_page = 0
        vntana.total_assets = 0

        add_timer(self, context)
        return {'RUNNING_MODAL'}


# Note(ivan): per Blender's documentation, this is needed so that strings are not GC'ed.
organization_cache = []
workspace_cache = []


def get_workspaces(self, context):
    api = get_async_api()
    global workspace_cache
    workspace_cache = [(ws.get('uuid', ''), ws.get('name', ''), '')
                       for ws in api.workspaces]
    return workspace_cache


def get_organizations(self, context):
    api = get_async_api()
    global organization_cache
    organization_cache = [(org.get('uuid', ''), org.get('name', ''), '')
                          for org in api.organizations]
    return organization_cache


class VNTANA_OT_select_org(VNTANA_OT_async_operator):
    bl_idname = "vntana.select_org"
    bl_label = "Select Organization"
    bl_description = "Select VNTANA organization"
    bl_property = "organization"
    bl_options = {'REGISTER', 'INTERNAL'}

    organization: EnumProperty(
        name="Organization",
        items=get_organizations
    )

    def execute(self, context):
        vntana = get_preferences().preferences.ui
        vntana.operation_message = "Selecting organization"
        self._task = create_task(select_org(
            get_async_api(), self.organization, ''))
        add_timer(self, context)

        vntana.assets.clear()
        vntana.current_page = 0
        vntana.total_assets = 0

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {'FINISHED'}

    def on_finish(self, context):
        context.preferences.is_dirty = True
        if bpy.ops.vntana.search_assets.poll():
            bpy.ops.vntana.search_assets('INVOKE_DEFAULT')


class VNTANA_OT_select_ws(VNTANA_OT_async_operator):
    bl_idname = "vntana.select_ws"
    bl_label = "Search Workspace"
    bl_description = "Select VNTANA workspace"
    bl_property = "workspace"

    workspace: EnumProperty(
        name="Workspace",
        items=get_workspaces
    )

    def execute(self, context):
        vntana = get_preferences().preferences.ui
        vntana.operation_message = "Selecting workspace"
        self._task = create_task(select_ws(get_async_api(), self.workspace))
        add_timer(self, context)
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {'FINISHED'}

    def on_finish(self, context):
        context.preferences.is_dirty = True
        if bpy.ops.vntana.search_assets.poll():
            bpy.ops.vntana.search_assets('INVOKE_DEFAULT')


class VNTANA_OT_fetch_presets(VNTANA_OT_async_operator):
    """Fetch presets from VNTANA"""
    bl_idname = "vntana.fetch_presets"
    bl_label = "Fetch Presets"
    bl_description = "Fetch optimization and viewer presets from VNTANA"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        status = {'RUNNING_MODAL'}
        vntana = get_preferences().preferences.ui
        vntana.property_unset('pipelines')
        vntana.property_unset('viewer_presets')
        vntana.property_unset('optimization_presets')
        # Clear existing presets
        if not get_async_api().client_uuid:
            self.report({'WARNING'}, "No workspace selected")
            status = {'CANCELLED'}
        else:
            vntana.operation_message = "Fetching presets"

            self._task = create_task(get_presets(get_async_api()))

            add_timer(self, context)

        return status


# Registration
classes = [
    VNTANA_OT_login,
    VNTANA_OT_logout,
    VNTANA_OT_fetch_presets,
    VNTANA_OT_select_org,
    VNTANA_OT_select_ws
]


def register():
    """Register auth operators."""
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    """Unregister auth operators."""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
