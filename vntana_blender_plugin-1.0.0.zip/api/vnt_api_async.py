# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Async API Client (aiohttp)

import asyncio
import json
import logging
from typing import Optional, Tuple, Dict, Any, List
from urllib.parse import urlparse
import aiohttp
from dataclasses import dataclass, field

from ..core import get_logger
from os import path


async def buffered_reader(bytes, progress_callback, chunk_size):
    total_size = len(bytes)
    position = 0
    while position < total_size:
        new_pos = min(position + chunk_size, total_size)
        progress_callback(new_pos, total_size)
        yield bytes[position:new_pos]
        position = new_pos


@dataclass
class ApiResponse:
    """Wrapper for API responses."""
    success: bool
    status_code: int
    data: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    headers: Dict[str, str] = field(default_factory=dict)


def mask_email(email: str) -> str:
    """
    Mask an email address for safe logging.

    Shows first 2 chars of local part and first char of domain.
    Example: user@example.com -> us***@e***

    Args:
        email: Email address to mask

    Returns:
        Masked email string
    """
    if not email or '@' not in email:
        return '***'

    try:
        local, domain = email.rsplit('@', 1)
        masked_local = local[:2] + \
            '***' if len(local) > 2 else local[0] + '***'
        masked_domain = domain[0] + '***' if domain else '***'
        return f"{masked_local}@{masked_domain}"
    except (ValueError, IndexError):
        return '***'


class VntApiAsync:
    """
    Async VNTANA Platform API Client using aiohttp.
    """

    def __init__(self):
        self.logger = get_logger()
        self._session = None

        self.x_auth_token = None
        self.refresh_token = None
        self.personal_access_token = None

        self.organization_uuid: str = ''
        self.client_uuid: str = ''  # workspace UUID
        self.user_email: str = ''
        self.user_role: str = ''

        self.organizations = []
        self.workspaces = []

        self.pipelines = []
        self.optimization_presets = []
        self.viewer_presets = []
        self.tags = []

        self.assets = []
        self.total_assets = 0

        self.timeout = 300
        self.connection_limit = 100

    def clear(self) -> None:
        self.x_auth_token = None
        self.refresh_token = None
        self.personal_access_token = None
        self.organization_uuid = ''
        self.client_uuid = ''
        self.user_email = ''
        self.user_role = ''
        self.organizations = []
        self.workspaces = []
        self.pipelines = []
        self.optimization_presets = []
        self.viewer_presets = []
        self.tags = []

        self.optimization_presets.append({})
        self.viewer_presets.append({})

    def is_authenticated(self):
        return self.x_auth_token

    def _ensure_session(self) -> aiohttp.ClientSession:
        # TODO(ivan): session needs to be initialized from the async loop. Do this once instead of calling everywhere.
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(
                ssl=True, limit=self.connection_limit)
            self._session = aiohttp.ClientSession(
                connector=connector, timeout=aiohttp.ClientTimeout(total=self.timeout))
        return self._session

    async def close(self):
        """Close the aiohttp session."""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None

    async def _send_request(self,
                            method: str,
                            url: str,
                            json_data: Optional[Dict] = None,
                            data: Optional[bytes] = None,
                            headers: Optional[Dict] = None) -> ApiResponse:
        """
        Send an async HTTP request to the API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            url: Full URL to request
            json_data: JSON body data
            data: Raw binary data
            headers: Additional headers

        Returns:
            ApiResponse with success status and data
        """
        session = self._ensure_session()

        request_headers = {
            'Content-Type': 'application/json'
        }

        # Snapshot the token once (no await between read and use)
        auth_token = self.x_auth_token
        if auth_token:
            request_headers['x-auth-token'] = auth_token

        if headers:
            request_headers.update(headers)

        try:
            async with session.request(
                method=method,
                url=url,
                json=json_data,
                data=data,
                headers=request_headers,
            ) as response:
                self.logger.debug(f"API {method} {url} -> {response.status}")

                response_data = {}
                errors = []

                body = await response.read()
                if body:
                    try:
                        response_data = json.loads(body)
                        errors = response_data.get('errors', [])
                        if isinstance(errors, list):
                            errors = [str(e.get('message', e) if isinstance(
                                e, dict) else e) for e in errors]
                    except json.JSONDecodeError as e:
                        self.logger.warning(
                            f"Failed to parse JSON response from {url}: {e}")
                        if self.logger.isEnabledFor(logging.DEBUG):
                            content_preview = body[:200] if body else b''
                            self.logger.debug(
                                f"Response content preview: {content_preview}")
                        errors = ["Invalid response format from server"]

                success = response.status == 200 and not errors

                return ApiResponse(
                    success=success,
                    status_code=response.status,
                    data=response_data,
                    errors=errors,
                    headers=dict(response.headers)
                )

        except asyncio.TimeoutError:
            self.logger.error(f"Request timeout: {url}")
            return ApiResponse(
                success=False,
                status_code=0,
                errors=["Request timed out"]
            )

        except aiohttp.ClientConnectionError as e:
            self.logger.error(f"Connection error: {e}")
            return ApiResponse(
                success=False,
                status_code=0,
                errors=["Connection failed. Please check your internet connection."]
            )

        except Exception as e:
            self.logger.exception(f"Request failed: {e}")
            return ApiResponse(
                success=False,
                status_code=0,
                errors=[str(e)]
            )

    # =========================================================================
    # Authentication
    # =========================================================================

    async def login_with_credentials(self, email: str, password: str) -> ApiResponse:
        self.clear()
        """Login with email and password."""
        self.logger.info(f"Logging in with email: {mask_email(email)}")

        response = await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/auth/login",
            json_data={'email': email, 'password': password}
        )

        if response.success:
            token = response.headers.get('x-auth-token')
            if token:
                self.x_auth_token = f'Bearer {token}'
                if email is not None:
                    self.user_email = email
                self.logger.info("Login successful")
            else:
                response.success = False
                response.errors = ["No authentication token received"]

        return response

    async def login_with_pat(self, pat: str) -> ApiResponse:
        self.clear()
        """Login with Personal Access Token."""
        self.logger.info("Logging in with PAT")

        response = await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/auth/login/token",
            json_data={'personal-access-token': pat}
        )

        if response.success:
            token = response.headers.get('x-auth-token')
            if token:
                self.x_auth_token = f'Bearer {token}'
                self.personal_access_token = pat
                self.user_email = response.data.get(
                    'response', {}).get('email', '')
                self.logger.info("PAT login successful")
            else:
                response.success = False
                response.errors = ["No authentication token received"]

        return response

    async def generate_refresh_token(self) -> ApiResponse:
        """Generate a refresh token for the current session."""
        headers = {
            'Content-Type': 'application/javascript',
            'organizationUuid': self.organization_uuid
        }

        if self.client_uuid:
            headers['clientUuid'] = self.client_uuid

        response = await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/auth/refresh-token",
            headers=headers
        )

        if response.success:
            token = response.headers.get('x-auth-token')
            if token:
                self.refresh_token = f'Bearer {token}'
                self.x_auth_token = self.refresh_token
                self.logger.debug("Refresh token generated")
            else:
                response.success = False
                response.errors = ["No refresh token received"]

        return response

    async def logout(self, base_url='') -> ApiResponse:
        """Logout and clear credentials."""
        self.logger.info("Logging out")

        if not base_url:
            base_url = self.base_url

        response = await self._send_request(
            method='POST',
            url=f"{base_url}/v1/auth/logout"
        )

        # Clear credentials regardless of response
        self.clear()

        return response

    # =========================================================================
    # Organizations and Workspaces
    # =========================================================================

    async def get_organizations(self) -> ApiResponse:
        """Get list of organizations the user has access to."""
        response = await self._send_request(
            method='GET',
            url=f"{self.base_url}/v1/organizations"
        )

        if response.success:
            orgs = response.data.get('response', {}).get('grid', [])
            self.organizations = orgs
            self.logger.debug(f"Found {len(orgs)} organizations")
        else:
            self.organizations = []

        return response

    async def get_workspaces(self) -> ApiResponse:
        """Get list of workspaces (clients) for current organization."""
        response = await self._send_request(
            method='GET',
            url=f"{self.base_url}/v1/clients/client-organizations"
        )

        workspaces = []
        if response.success:
            workspaces = response.data.get('response', {}).get('grid', [])
            self.logger.debug(f"Found {len(workspaces)} workspaces")

        self.workspaces = workspaces

        return response

    async def select_organization(self, org):
        self.user_role = org.get('role', '')
        self.organization_uuid = org.get('uuid', '')
        self.client_uuid = ''
        return await self.generate_refresh_token()

    async def select_workspace(self, ws):
        self.client_uuid = ws.get('uuid', '')
        if self.client_uuid and self.user_role != 'ORGANIZATION_OWNER' and self.user_role != 'ORGANIZATION_ADMIN':
            await self.generate_refresh_token()

    async def get_user_grants(self) -> ApiResponse:
        """Get user permissions/grants."""
        return await self._send_request(
            method='GET',
            url=f"{self.base_url}/v1/users/grants"
        )

    # =========================================================================
    # Asset Management
    # =========================================================================

    async def search_assets(self,
                            page: int = 1,
                            size: int = 20,
                            search_term: str = "",
                            name: str = "") -> ApiResponse:
        self.assets = []
        """Search for assets in the current workspace."""
        client_uuid = self.client_uuid
        if not client_uuid:
            return ApiResponse(
                success=False, status_code=0,
                errors=["No workspace selected"]
            )

        body = {
            "page": page,
            "size": size
        }
        if search_term:
            body['searchTerm'] = search_term

        res = await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/products/clients/{client_uuid}/search",
            json_data=body
        )

        return res

    async def get_asset(self, asset_uuid: str) -> ApiResponse:
        """Get asset details by UUID."""
        return await self._send_request(
            method='GET',
            url=f"{self.base_url}/v1/products/{asset_uuid}"
        )

    async def create_asset(self,
                           name: str,
                           model_ops_parameters: Dict,
                           tags_uuids: List[str] = None,
                           preset_uuid: Optional[str] = None,
                           viewer_preset_uuid: Optional[str] = None,
                           pipeline_uuid: Optional[str] = None,
                           description: str = "",
                           publish_to_status: str = "DRAFT",
                           attributes={}
                           ) -> ApiResponse:
        """Create a new asset."""
        client_uuid = self.client_uuid
        if not client_uuid:
            return ApiResponse(
                success=False, status_code=0,
                errors=["No workspace selected"]
            )

        viewer_settings = {}
        if viewer_preset_uuid:
            viewer_settings['presetUuid'] = viewer_preset_uuid

        body = {
            'name': name,
            'clientUuid': client_uuid,
            'description': description,
            'tags': [],
            'attributes': attributes,
            'publishToStatus': publish_to_status,
            'rendererConfigs': None,
            'pipelineUuid': pipeline_uuid,
            'presetUuid': preset_uuid,
            'tagsUuids': tags_uuids or [],
            'deleteAsset': False,
            'modelOpsParameters': model_ops_parameters,
            'projectsUuids': [],
            'viewerSettings': viewer_settings
        }

        return await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/products",
            json_data=body
        )

    async def update_asset(self,
                           asset_uuid: str,
                           name: str,
                           model_ops_parameters: Dict,
                           tags_uuids: List[str] = None,
                           preset_uuid: Optional[str] = None,
                           viewer_preset_uuid: Optional[str] = None,
                           pipeline_uuid: Optional[str] = None,
                           description: str = "",
                           publish_to_status: str = "DRAFT") -> ApiResponse:
        """Update an existing asset."""
        client_uuid = self.client_uuid
        if not client_uuid:
            return ApiResponse(
                success=False, status_code=0,
                errors=["No workspace selected"]
            )

        viewer_settings = {}
        if viewer_preset_uuid:
            viewer_settings['presetUuid'] = viewer_preset_uuid

        body = {
            'uuid': asset_uuid,
            'name': name,
            'clientUuid': client_uuid,
            'description': description,
            'tags': [],
            'attributes': {},
            'publishToStatus': publish_to_status,
            'rendererConfigs': None,
            'pipelineUuid': pipeline_uuid,
            'presetUuid': preset_uuid,
            'tagsUuids': tags_uuids or [],
            'deleteAsset': False,
            'modelOpsParameters': model_ops_parameters,
            'projectsUuids': [],
            'viewerSettings': viewer_settings
        }

        return await self._send_request(
            method='PUT',
            url=f"{self.base_url}/v1/products",
            json_data=body
        )

    # =========================================================================
    # File Upload/Download
    # =========================================================================

    async def get_signed_upload_url(self,
                                    product_uuid: str,
                                    filename: str,
                                    file_size: int) -> ApiResponse:
        """Get a signed URL for uploading a file."""
        client_uuid = self.client_uuid
        if not client_uuid:
            return ApiResponse(
                success=False, status_code=0,
                errors=["No workspace selected"]
            )

        body = {
            'clientUuid': client_uuid,
            'productUuid': product_uuid,
            'resourceSettings': {
                'contentType': 'application/octet-stream',
                'originalName': filename,
                'originalSize': file_size
            }
        }

        return await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/storage/upload/clients/products/asset/sign-url",
            json_data=body,
            headers={'Origin': self.base_url}
        )

    async def upload_file(self, signed_url: str, file_data: bytes, progress_callback) -> ApiResponse:
        """Upload a file to the signed URL."""
        try:
            session = self._ensure_session()
            # TODO(ivan): The best value for this depends on network conditions, where the bytes come from (memory or disk) and the refresh rate of the plugin.
            # Possibly, this should be calculated dynamically, but for now, let's use a high enough value that will not throttle the network under average conditions.
            buffer_size = 8 * 1024 * 1024
            async with session.put(
                signed_url,
                data=buffered_reader(
                    file_data, progress_callback, buffer_size),
                headers={
                    'Origin': self.base_url,
                    'Content-Type': 'application/octet-stream',
                    'Content-Length': str(len(file_data))
                },
                timeout=None,
            ) as response:
                return ApiResponse(
                    success=response.status in [200, 201],
                    status_code=response.status,
                    errors=[] if response.status in [200, 201] else ["Upload failed"]
                )
            return ApiResponse(success=response.status_code in [200, 201], status_code=response.status_code, errors=[])

        except Exception as e:
            self.logger.exception(f"Upload failed: {type(e)}")
            return ApiResponse(
                success=False,
                status_code=0,
                errors=[]
            )

    async def download_asset_original(self, product_uuid: str) -> Tuple[bool, Optional[bytes], str]:
        """Download the original asset file."""
        client_uuid = self.client_uuid
        refresh_token = self.refresh_token
        if not client_uuid or not refresh_token:
            return False, None, "Not authenticated or no workspace selected"

        url = f"{self.base_url}/v1/products/{product_uuid}/download/asset?clientUuid={client_uuid}"

        try:
            session = self._ensure_session()
            async with session.get(
                url,
                headers={'x-auth-token': refresh_token},
                timeout=None
            ) as response:
                if response.status == 200:
                    data = await response.read()
                    return True, data, ""
                else:
                    return False, None, f"Download failed with status {response.status}"

        except Exception as e:
            self.logger.exception(f"Download failed: {e}")
            return False, None, str(e)

    async def download_optimized_model(self,
                                       product_uuid: str,
                                       conversion_format: str = "GLB",
                                       progress_callback=None) -> Tuple[bool, Optional[bytes], str]:
        """Download the optimized model."""
        client_uuid = self.client_uuid
        refresh_token = self.refresh_token
        if not client_uuid or not refresh_token:
            return False, None, "Not authenticated or no workspace selected"

        url = (f"{self.base_url}/v1/products/{product_uuid}/download/model"
               f"?clientUuid={client_uuid}&conversionFormat={conversion_format}")

        try:
            session = self._ensure_session()
            async with session.get(
                url,
                headers={'x-auth-token': refresh_token},
                timeout=None
            ) as response:
                if response.status == 200:
                    total = response.content_length or 0
                    downloaded = 0
                    chunks = []
                    async for chunk, _ in response.content.iter_chunks():
                        chunks.append(chunk)
                        downloaded += len(chunk)
                        if progress_callback and total:
                            progress_callback(downloaded, total)
                    data = b''.join(chunks)
                    return True, data, ""
                else:
                    return False, None, f"Download failed with status {response.status}"

        except Exception as e:
            self.logger.exception(f"Download failed: {e}")
            return False, None, str(e)

    async def download_thumbnail(self, blob_id: str,
                                 width: int = 128, height: int = 128) -> Tuple[bool, Optional[bytes], str]:
        """Download an asset thumbnail/poster."""
        client_uuid = self.client_uuid
        refresh_token = self.refresh_token
        if not client_uuid or not refresh_token:
            return False, None, "Not authenticated or no workspace selected"

        url = f"{self.base_url}/v1/storage/load/clients/{client_uuid}/thumbnail/{blob_id}"
        params = {'options': f'{width}x{height}'}

        try:
            self.logger.debug(f"Downloading thumbnail: {url}")
            session = self._ensure_session()
            async with session.get(
                url,
                headers={'x-auth-token': refresh_token},
                params=params,
                timeout=None
            ) as response:
                if response.status == 200:
                    data = await response.read()
                    self.logger.debug(
                        f"Thumbnail downloaded successfully: {len(data)} bytes")
                    return True, data, ""
                else:
                    self.logger.warning(
                        f"Thumbnail download failed: status={response.status}")
                    return False, None, f"Thumbnail download failed with status {response.status}"

        except Exception as e:
            self.logger.exception(f"Thumbnail download failed: {e}")
            return False, None, str(e)

    # =========================================================================
    # Presets and Tags
    # =========================================================================

    async def get_optimization_presets(self):
        self.optimization_presets = []
        self.optimization_presets.append({})

        """Get optimization presets for the current workspace."""
        client_uuid = self.client_uuid
        res = await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/presets/search",
            json_data={
                'page': 0,
                'size': 1000,
                'clientUuid': client_uuid
            }
        )

        if res.success:
            grid = res.data.get('response', {}).get('grid', [])
            for preset in grid:
                preset_type = preset.get('type', '')
                # TODO(ivan): is this needed? why is it not filtered server side?
                if preset_type == 'CLIENT':
                    if preset.get('clientUuid', '') == self.client_uuid:
                        self.optimization_presets.append(preset)
                else:
                    self.optimization_presets.append(preset)
        else:
            self.logger.warning(
                f"Failed to fetch optimization presets: {res.errors}")

    async def get_viewer_presets(self) -> ApiResponse:
        self.viewer_presets = []
        self.viewer_presets.append({})
        """Get viewer presets for the current organization."""
        res = await self._send_request(
            method='GET',
            url=f"{self.base_url}/v1/viewer-presets/by-organization"
        )
        if res.success:
            grid = res.data.get('response', {}).get('grid', [])
            for preset in grid:
                preset_type = preset.get('type', '')
                if preset_type == 'CLIENT':
                    if preset.get('clientUuid', '') == self.client_uuid:
                        self.viewer_presets.append(preset)
                else:
                    self.viewer_presets.append(preset)
        else:
            self.logger.warning(
                f"Failed to fetch viewer presets: {res.errors}")

    async def get_pipelines(self) -> ApiResponse:
        self.pipelines = []
        """Get available pipelines."""
        res = await self._send_request(
            method='GET',
            url=f"{self.base_url}/v1/pipelines"
        )

        if res.success:
            # API returns response.pipelines (not response.grid like other endpoints)
            self.pipelines = res.data.get(
                'response', {}).get('pipelines', [])
        else:
            self.logger.warning(
                f"Failed to fetch pipelines: {res.errors}")

    async def search_tags(self, search_term: str = "", page: int = 1,
                          size: int = 100000) -> ApiResponse:
        """Search tags in the current workspace."""
        json_data = {
            'clientUuid': self.client_uuid,
            'page': page,
            'size': size,
            'searchTerm': search_term
        }
        if search_term:
            json_data['searchTerm'] = search_term

        res = await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/tags/search",
            json_data=json_data
        )
        if res.success:
            self.tags = res.data.get('response', {}).get('grid', [])

    async def get_tag_uuid(self, tag: str) -> str:
        body = {
            'clientUuid': self.client_uuid,
            'searchTerm': tag,
            'page': 1,
            'size': 1
        }

        res = await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/tags/search",
            json_data=body
        )
        if res.success:
            grid = res.data.get('grid', [])
            if len(grid) > 0:
                if grid[0]['name'] == tag:
                    return grid[0]['uuid']
        return None

    async def create_tag(self, name: str,
                         tag_group_uuid: Optional[str] = None) -> ApiResponse:
        """Create a new tag."""
        client_uuid = self.client_uuid
        body = {
            'clientUuid': client_uuid,
            'name': name
        }

        if tag_group_uuid:
            body['tagGroupUuid'] = tag_group_uuid

        res = await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/tags/create",
            json_data=body
        )
        if res.success:
            return res.data.get('response', {}).get('uuid', '')

        return ''

    # =========================================================================
    # Projects
    # =========================================================================

    async def search_projects(self,
                              search_term: str = "",
                              page: int = 0,
                              size: int = 100) -> ApiResponse:
        """Search projects in the current workspace."""
        client_uuid = self.client_uuid
        if not client_uuid:
            return ApiResponse(
                success=False, status_code=0,
                errors=["No workspace selected"]
            )

        return await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/projects/search",
            json_data={
                'page': page,
                'size': size,
                'clientUuids': [client_uuid],
                'searchTerm': search_term,
                'includeProductsSearch': False,
                'sorts': {'CREATED': 'DESC'}
            }
        )

    async def create_project(self, name: str, description: str = "") -> ApiResponse:
        """Create a new project."""
        client_uuid = self.client_uuid
        if not client_uuid:
            return ApiResponse(
                success=False, status_code=0,
                errors=["No workspace selected"]
            )

        return await self._send_request(
            method='POST',
            url=f"{self.base_url}/v1/projects",
            json_data={
                'clientUuid': client_uuid,
                'name': name,
                'description': description,
                'parentUuid': None,
                'thumbnailUuid': None,
                'status': 'LIVE_INTERNAL',
                'locationsUuids': [],
                'tagsUuids': [],
                'attributes': {},
                'productsUuids': [],
                'subProjects': [],
                'publishProductsToStatus': False
            }
        )

    async def link_assets_to_project(self,
                                     project_uuid: str,
                                     asset_uuids: List[str]) -> ApiResponse:
        """Link assets to a project."""
        return await self._send_request(
            method='PUT',
            url=f"{self.base_url}/v1/projects/link-products",
            json_data={
                'uuids': [project_uuid],
                'productsUuids': asset_uuids,
                'project': {}
            }
        )


# Singleton API instance
_async_api_instance: Optional[VntApiAsync] = None


def init_api(base_url, timeout=0, connection_limit=0):
    global _async_api_instance
    _async_api_instance = VntApiAsync()
    _async_api_instance.base_url = base_url
    if timeout > 0:
        _async_api_instance.timeout = timeout
    if connection_limit > 0:
        _async_api_instance.connection_limit = connection_limit


def get_async_api():
    global _async_api_instance
    return _async_api_instance


async def reset_async_api():
    """Reset the async API instance, closing the session."""
    global _async_api_instance
    if _async_api_instance is not None:
        await _async_api_instance.close()
    _async_api_instance = None
