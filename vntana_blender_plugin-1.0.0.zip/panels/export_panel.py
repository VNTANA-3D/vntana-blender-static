# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Export Panel

import bpy
from bpy.types import Panel, UIList

from ..api.vnt_api_async import get_async_api

from ..core import get_preferences


class VNTANA_UL_tags(UIList):
    """Asset list UI"""
    bl_idname = "VNTANA_UL_tags"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(data, "name", text='')


class VNTANA_PT_export(Panel):
    """Export to VNTANA panel"""
    bl_label = "Export to VNTANA"
    bl_idname = "VNTANA_PT_export"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "VNTANA"
    bl_parent_id = "VNTANA_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        auth = get_async_api()
        return auth.is_authenticated() and auth.client_uuid

    def draw(self, context):
        layout = self.layout
        prefs = get_preferences().preferences
        export_settings = prefs.ui.export_settings

        if prefs.ui.operation_message and prefs.ui.export_progress > 0:
            layout.progress(text='Exporting to VNTANA',
                            factor=prefs.ui.export_progress)
        else:
            layout.label(text="Asset Details")

            layout.prop(prefs.ui, "asset_name", text="Name")

            layout.prop(prefs.ui, "description")

            tags_header, tags_list = layout.panel(
                idname="vntana_tags", default_closed=True)
            tags_header.label(text="Tags")
            if tags_list:
                tags_list.operator("vntana.add_tag", icon='ADD')
                for idx, tag in enumerate(prefs.ui.tags):
                    row = tags_list.row()
                    row.prop(tag, "name", text="")
                    op = row.operator("vntana.remove_tag",
                                      icon='REMOVE', text="")
                    op.index = idx

            attributes_header, attributes_list = layout.panel(
                idname="vntana_attributes", default_closed=True)
            attributes_header.label(text="Attributes")
            if attributes_list:
                attributes_list.operator("vntana.add_attribute", icon='ADD')
                row = attributes_list.row()
                for idx, attr in enumerate(prefs.ui.attributes):
                    row = attributes_list.row()
                    row.prop(attr, "name", text="", placeholder="Name")
                    row.prop(attr, "value", text="", placeholder="Value")
                    op = row.operator(
                        "vntana.remove_attribute", icon='REMOVE', text="")
                    op.index = idx

            layout.separator(type='LINE')

            # Basic export options
            layout.prop(prefs.ui, "export_selected")
            layout.prop(prefs.ui, "apply_modifiers")
            layout.prop(prefs.ui, "export_animations")

            layout.separator(type='LINE')

            layout.label(text="Optimization")
            layout.prop(prefs.ui, 'pipelines')
            layout.prop(prefs.ui, 'optimization_presets')
            layout.prop(prefs.ui, 'viewer_presets')
            # Refresh button
            layout.operator("vntana.fetch_presets",
                            text="Refresh Presets", icon='FILE_REFRESH')

            layout.separator(type='LINE')

            advanced_settings_header, advanced_settings = layout.panel(
                idname="vntana_advanced_settings", default_closed=True)
            advanced_settings_header.label(text="Advanced Setttings")

            if advanced_settings:
                file_size_limit_box = advanced_settings.box()
                file_size_limit_box.prop(
                    export_settings, "file_size_limit", toggle=True)
                if export_settings.file_size_limit:
                    file_size_limit_box.prop(
                        export_settings, "file_size_limit_in_mb")
                    file_size_limit_box.prop(
                        export_settings, "force_file_size_limit")

                geom_opts = advanced_settings.box()
                geom_opts.prop(export_settings,
                               "geometry_optimization", toggle=True)
                if export_settings.geometry_optimization:
                    geom_opts.prop(
                        export_settings, "remove_obstructed_geometry")
                    geom_opts.prop(export_settings, "polygon_limit")
                    geom_opts.prop(export_settings, "force_polygon_count")
                    geom_opts.prop(export_settings, "small_feature_baking")
                    geom_opts.prop(export_settings, "freeze_transforms")

                draco_opts = advanced_settings.box()
                draco_opts.prop(export_settings,
                                "draco_compression", toggle=True)

                tex_opts = advanced_settings.box()
                tex_opts.prop(export_settings,
                              "texture_optimization", toggle=True)

                if export_settings.texture_optimization:
                    tex_opts.prop(export_settings, "texture_compression")
                    tex_opts.prop(export_settings, "max_texture_dimension")
                    tex_opts.prop(export_settings, "use_ktx")

                    tex_opts.prop(export_settings,
                                  "bake_ambient_occlusion", toggle=True)
                    if export_settings.bake_ambient_occlusion:
                        tex_opts.prop(export_settings, "ao_strength")
                        tex_opts.prop(export_settings, "ao_radius")
                        tex_opts.prop(export_settings, "ao_resolution")

                    tex_opts.prop(export_settings, "fbx_pbr_textures")

                model_scaling_opts = advanced_settings.box()
                model_scaling_opts.prop(
                    export_settings, "model_scaling", toggle=True)

                if export_settings.model_scaling:
                    model_scaling_opts.prop(
                        export_settings, "axis_to_scale_on")
                    model_scaling_opts.prop(export_settings, "size")
                    model_scaling_opts.prop(export_settings, "unit")

                advanced_settings.prop(export_settings, "pivot_point")

                # Reset settings
                advanced_settings.operator("vntana.reset_export_settings",
                                           text="Reset Settings", icon='LOOP_BACK')

            layout.separator(type='LINE')

            layout.prop(export_settings, "publish_to_status")

            layout.separator(type='LINE')
            # Export button
            row = layout.row()
            row.scale_y = 1.5
            row.operator("vntana.export", text="Create", icon='EXPORT')

            layout.separator()


# Registration
classes = [
    VNTANA_PT_export,
    VNTANA_UL_tags,
]


def register():
    """Register export panels."""
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    """Unregister export panels."""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
