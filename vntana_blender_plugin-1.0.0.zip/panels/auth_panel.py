# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Authentication Panel

import bpy
from bpy.types import Panel

from ..api.vnt_api_async import get_async_api
from ..core import get_preferences


def get_name(list, uuid, default):
    for item in list:
        if item.get('uuid', '') == uuid:
            return item.get('name', default)
    return default


class VNTANA_PT_main(Panel):
    """Main VNTANA panel in the sidebar"""
    bl_label = "VNTANA"
    bl_idname = "VNTANA_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "VNTANA"

    def draw(self, context):
        layout = self.layout
        prefs = get_preferences().preferences
        vntana = prefs.ui
        auth = get_async_api()

        if vntana.operation_message:
            anim_freq = 1.0 / 3.0
            count = int(vntana.operation_progress / anim_freq)
            prog = (count % 3) + 1
            layout.label(text=vntana.operation_message + '.' * prog)
        elif not bpy.app.online_access:
            layout.label(text="Allow online access to login.",
                         icon='WARNING_LARGE')
        else:
            # Note(ivan): this is so that the layout is stable and doesn't jump on each operation.
            layout.label(text='')

        if not auth.is_authenticated():
            box = layout.box()
            box.label(text="Login to VNTANA", icon='USER')

            # Login method toggle
            row = box.row(align=True)
            row.prop(prefs, "login_method", expand=True)

            if prefs.login_method == 'PAT':
                box.prop(vntana, "login_pat")
                box.prop(prefs, "remember_pat")
            else:
                box.prop(vntana, "login_email")
                box.prop(vntana, "login_password")

            box.separator()

            # Login button
            row = box.row()
            row.scale_y = 1.5
            op = row.operator("vntana.login", text="Login", icon='CHECKMARK')
            if prefs.login_method == 'PAT':
                op.pat = vntana.login_pat
            else:
                op.username = vntana.login_email
                op.password = vntana.login_password
        else:
            box = layout.box()
            row = box.row()
            row.label(text=auth.user_email or "Logged in", icon='USER')
            box.operator("vntana.select_org", text=get_name(auth.organizations, auth.organization_uuid, "Select Organization"),
                         depress=bool(auth.organization_uuid), icon='FILE_VOLUME')
            if auth.organization_uuid:
                box.operator("vntana.select_ws", text=get_name(auth.workspaces, auth.client_uuid, "Select Workspace"),
                             depress=bool(auth.client_uuid), icon='FILE_FOLDER')
            box.operator("vntana.logout", text="Logout", icon='PANEL_CLOSE')


# Registration
classes = [
    VNTANA_PT_main,
]


def register():
    """Register auth panels."""
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    """Unregister auth panels."""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
