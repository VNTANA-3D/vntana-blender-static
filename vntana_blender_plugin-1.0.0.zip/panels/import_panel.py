# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Import Panel

from datetime import datetime

import bpy
from bpy.types import Panel, UIList

from ..api.vnt_api_async import get_async_api
from .. import get_icons
from ..core import get_preferences


def get_icon_id(blob_id):
    store = get_icons()
    icon = store.preview_collections.get(blob_id, None)
    return icon.icon_id if icon else 0


optimization_status_def = {
    'COMPLETED': ('Completed', 'CHECKMARK'),
    'FAILED': ('Failed', 'PANEL_CLOSE'),
    'TERMINATED': ('Terminated', 'PANEL_CLOSE'),
    'RUNNING': ('Running', 'TIME'),
    'PENDING': ('Pending', 'TIME'),
    'IN_PROGRESS': ('In Progress', 'TIME'),
    'NO_ASSET': ('No Asset', 'REMOVE')
}


def get_opt_status_icon(status):
    global optimization_status_def
    return optimization_status_def.get(status, ('', 'REMOVE'))[1]


def get_opt_status_name(status):
    global optimization_status_def
    return optimization_status_def.get(status, ('', 'REMOVE'))[0]


class VNTANA_UL_attributes(UIList):
    """Attribute key/value list UI"""
    bl_idname = "VNTANA_UL_attributes"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=f"{item.name}:")
        row.label(text=item.value)


class VNTANA_UL_assets(UIList):
    """Asset list UI"""
    bl_idname = "VNTANA_UL_assets"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)

            # Try to get thumbnail icon

            icon_id = get_icon_id(item.thumbnail_blob_id)
            if icon_id:
                row.label(text=item.name, icon_value=icon_id)
            else:
                row.label(text=item.name, icon='OBJECT_DATA')

            # Status indicator
            row.label(text="", icon=get_opt_status_icon(
                item.optimization_status))

        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            icon_id = get_icon_id(item.thumbnail_blob_id)
            if icon_id:
                layout.label(text="", icon_value=icon_id)
            else:
                layout.label(text="", icon='OBJECT_DATA')


class VNTANA_PT_import(Panel):
    """Import from VNTANA panel"""
    bl_label = "Import from VNTANA"
    bl_idname = "VNTANA_PT_import"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "VNTANA"
    bl_parent_id = "VNTANA_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        auth = get_async_api()
        return auth.is_authenticated() and auth.client_uuid

    def draw(self, context):
        layout = self.layout
        prefs = get_preferences().preferences
        vntana = prefs.ui

        if vntana.download_progress < 0:
            # Search bar
            row = layout.row(align=True)
            row.prop(vntana, "asset_search_term", text="", icon='VIEWZOOM')
            op_refresh_assets = row.operator(
                "vntana.search_assets", text="", icon='FILE_REFRESH')
            op_refresh_assets.page = 1

            # View mode toggle and page size
            row = layout.row(align=True)

            # View mode buttons
            row.prop(prefs, "asset_view_mode", icon_only=True, expand=True)
            row.separator()

            # Page size dropdown
            row.label(text="Per page:")
            row.prop(prefs, "page_size_enum", text="")

            # Asset view - List or Grid
            if prefs.asset_view_mode == 'LIST':
                self.draw_list_view(context, layout, vntana)
            else:
                self.draw_grid_view(context, layout, vntana)

            # Pagination
            if vntana.total_assets > 0:
                page_size = int(prefs.page_size_enum)
                total_pages = (vntana.total_assets +
                               page_size - 1) // page_size
                current_page = vntana.current_page

                row = layout.row(align=True)
                row.alignment = 'CENTER'

                left = row.column()
                left.enabled = current_page > 1
                op_left = left.operator("vntana.search_assets",
                                        text="", icon='TRIA_LEFT')
                op_left.page = current_page - 1

                row.label(text=f"Page {current_page} of {total_pages}")

                right = row.column()
                right.enabled = current_page < total_pages
                op_right = right.operator("vntana.search_assets",
                                          text="", icon='TRIA_RIGHT')
                op_right.page = current_page + 1

                layout.label(text=f"Total: {vntana.total_assets} assets")

            # Import button
            layout.separator()
            row = layout.row()
            row.scale_y = 1.5

            asset = None
            if vntana.assets and 0 <= vntana.active_asset_index < len(vntana.assets):
                asset = vntana.assets[vntana.active_asset_index]

            op = row.operator("vntana.import_asset",
                              text="IMPORT SELECTED", icon='IMPORT')
            if asset and asset.uuid:
                op.asset_uuid = asset.uuid
                op.asset_name = asset.name

            if asset:
                # Info about selected asset with thumbnail
                layout.separator()
                layout.label(text="Selected Asset", icon='INFO')
                box = layout.box()
                box.label(text=asset.name)
                icon_id = get_icon_id(asset.thumbnail_blob_id)
                if icon_id:
                    box.template_icon(icon_value=icon_id, scale=6.0)
                else:
                    box.label(text="", icon='OBJECT_DATA')

                row = box.row()
                if asset.description:
                    row.label(text="Description:")
                    row.label(text=asset.description)

                row = box.row()
                row.label(text="Optimization Status:")
                row.label(
                    text=get_opt_status_name(asset.optimization_status), icon=get_opt_status_icon(asset.optimization_status))

                if asset.updated_at:
                    row = box.row()
                    date_str = datetime.fromisoformat(asset.updated_at).ctime()
                    row.label(text="Updated:")
                    row.label(text=date_str)

                if len(asset.tags):
                    row = box.row()
                    row.label(text='Tags:')
                    row.label(text=",".join([tag.name for tag in asset.tags]))

                if len(asset.attributes):
                    box.label(text='Attributes:')
                    box.template_list(
                        "VNTANA_UL_attributes",
                        "",
                        asset,
                        "attributes",
                        vntana,
                        "active_attribute_index",
                        rows=3
                    )

        else:
            layout.progress(text='Downloading from VNTANA',
                            factor=vntana.download_progress)

    def draw_list_view(self, context, layout, vntana):
        """Draw assets as a list."""
        row = layout.row()
        row.template_list(
            "VNTANA_UL_assets",
            "",
            vntana,
            "assets",
            vntana,
            "active_asset_index",
            rows=5
        )

    def draw_grid_view(self, context, layout, vntana):
        """Draw assets as a thumbnail grid."""
        if not vntana.assets:
            layout.label(text="No assets found", icon='INFO')
            return

        # Create a grid with 3 columns
        grid = layout.grid_flow(row_major=True, columns=3,
                                even_columns=True, even_rows=True, align=True)

        for index, asset in enumerate(vntana.assets):
            # Create a box for each asset
            box = grid.box()

            # Highlight selected asset
            if index == vntana.active_asset_index:
                box.alert = True

            col = box.column(align=True)

            # Thumbnail
            icon_id = get_icon_id(asset.thumbnail_blob_id)
            if icon_id:
                col.template_icon(icon_value=icon_id, scale=4.0)
            else:
                # Placeholder - show a centered icon
                placeholder = col.column(align=True)
                placeholder.scale_y = 4.0
                placeholder.label(text="", icon='RENDER_RESULT')

            # Asset name (truncated)
            op = col.operator("vntana.select_asset", text=asset.name)
            op.index = index


# Registration
classes = [
    VNTANA_UL_attributes,
    VNTANA_UL_assets,
    VNTANA_PT_import,
]


def register():
    """Register import panels."""
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    """Unregister import panels."""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
