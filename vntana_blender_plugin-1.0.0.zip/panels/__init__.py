# SPDX-License-Identifier: MIT
# VNTANA Blender Plugin - Panels Module

from . import auth_panel
from . import export_panel
from . import import_panel

__all__ = ['auth_panel', 'export_panel', 'import_panel']


def register():
    """Register all panels."""
    auth_panel.register()
    export_panel.register()
    import_panel.register()


def unregister():
    """Unregister all panels."""
    import_panel.unregister()
    export_panel.unregister()
    auth_panel.unregister()
