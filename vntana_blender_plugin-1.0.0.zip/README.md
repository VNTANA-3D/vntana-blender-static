# VNTANA Blender Plugin

A Blender addon for exporting 3D assets to and importing from the VNTANA platform.

## Requirements

- Blender 4.2 or later

## Installation

In Blender, go to **Edit > Preferences > Add-ons** and install from disk selecting the zip archive containing this repo. Make sure that online access is allowed in Blender system preferences.

## Usage

### Authentication

1. Open the **VNTANA** panel in the 3D View sidebar (press `N` to toggle)
2. Log in using either:
   - **Personal Access Token (PAT)**: Recommended for security
   - **Email & Password**: Traditional login

3. Select your **Organization** and **Workspace**

Your PAT can be stored for automatic login on future sessions.

### Export to VNTANA

1. Ensure you're logged in and have selected a workspace
2. Expand the **Export to VNTANA** panel
3. Configure export settings:
   - **Name**: Asset name in VNTANA (defaults to blend file name)
   - **Selected Only**: Export only selected objects
   - **Apply Modifiers**: Apply modifiers before export
   - **Export Animations**: Include animations

4. Configure advanced optimization settings (optional):
   - **Geometry Optimization**: Polygon limit, obstructed geometry removal
   - **Texture Optimization**: Compression level, max dimension, KTX format
   - **Ambient Occlusion**: AO baking settings
   - **Draco Compression**: Mesh compression (handled by VNTANA)
   - **Pivot Point**: Center, bottom, or original

5. Click **EXPORT TO VNTANA**

### Import from VNTANA

1. Ensure you're logged in and have selected a workspace
2. Expand the **Import from VNTANA** panel
3. Use the search bar to filter assets
4. Click **Refresh** to load assets
5. Select an asset from the list
6. Click **IMPORT SELECTED**

## Settings Storage

- **PAT**: Stored in `~/Library/Application Support/VNTANA/vntana-blender-plugin/pat.v` (macOS)
- **Config**: Stored in `~/Library/Application Support/VNTANA/vntana-blender-plugin/config.json`
- **Logs**: Stored in `~/Library/Application Support/VNTANA/vntana-blender-plugin/vntana-blender.log`

## Troubleshooting

### Login Issues

- Verify your credentials are correct
- Check internet connectivity
- Ensure your PAT hasn't expired

### Export Issues

- Ensure you have objects in the scene (or selected if using "Selected Only")
- Check the Blender console for detailed error messages
- Verify your workspace has upload permissions

### Import Issues

- Check that the asset has been processed by VNTANA
- Large assets may take time to download
- Check the log file for detailed error messages

## License

MIT License
