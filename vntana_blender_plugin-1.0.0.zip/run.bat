@echo off
call install.bat
echo Running...
blender
